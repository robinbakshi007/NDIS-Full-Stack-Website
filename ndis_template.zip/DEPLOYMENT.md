
# Deployment Guide

Complete guide for deploying your NDIS Template to production.

## Prerequisites

- Completed local development setup
- Production database (PostgreSQL or MySQL)
- Domain name (optional but recommended)
- Hosting platform account (Vercel, Netlify, etc.)

## Option 1: Vercel Deployment (Recommended)

### Step 1: Prepare Repository

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit"

# Push to GitHub
git remote add origin your-github-repo-url
git push -u origin main
```

### Step 2: Database Setup

Choose a production database:

**Option A: Vercel Postgres**
```bash
# Install Vercel CLI
npm i -g vercel

# Link project
vercel link

# Create database
vercel postgres create
```

**Option B: Supabase**
1. Create account at supabase.com
2. Create new project
3. Copy connection string
4. Use in Vercel environment variables

**Option C: Railway**
1. Create account at railway.app
2. Create PostgreSQL database
3. Copy connection string

### Step 3: Deploy to Vercel

1. Go to [vercel.com](https://vercel.com)
2. Click "Import Project"
3. Import from GitHub
4. Configure project:
   - Framework Preset: Next.js
   - Root Directory: `nextjs_space`
   - Build Command: `yarn build`
   - Install Command: `yarn install`

### Step 4: Environment Variables

Add all environment variables from `.env`:

```env
DATABASE_URL=your-production-database-url
NEXTAUTH_SECRET=generate-new-secret-for-production
NEXTAUTH_URL=https://yourdomain.com
AWS_BUCKET_NAME=your-bucket
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
AWS_REGION=ap-southeast-2
```

Generate new `NEXTAUTH_SECRET`:
```bash
openssl rand -base64 32
```

### Step 5: Deploy

Click "Deploy" and wait for the build to complete.

### Step 6: Run Database Migrations

```bash
# Install Vercel CLI
npm i -g vercel

# Link to production
vercel link

# Run migrations
vercel env pull .env.production
yarn prisma generate
yarn prisma db push
yarn prisma db seed
```

### Step 7: Custom Domain (Optional)

1. In Vercel dashboard, go to Settings > Domains
2. Add your custom domain
3. Update DNS records as instructed
4. Update `NEXTAUTH_URL` environment variable

## Option 2: Netlify Deployment

### Step 1: Prepare Build

1. Push code to GitHub
2. Go to [netlify.com](https://netlify.com)
3. Click "Add new site" > "Import an existing project"

### Step 2: Configure Build

- Build command: `cd nextjs_space && yarn build`
- Publish directory: `nextjs_space/.next`
- Functions directory: `nextjs_space/netlify/functions`

### Step 3: Environment Variables

Add all required environment variables in Netlify dashboard.

### Step 4: Database

Use Railway, Supabase, or PlanetScale for the database.

## Option 3: Railway Deployment

Railway provides both app hosting and database.

### Step 1: Database

1. Go to [railway.app](https://railway.app)
2. Create new project
3. Add PostgreSQL service
4. Copy connection string

### Step 2: Deploy App

1. Connect GitHub repository
2. Add environment variables
3. Set root directory to `nextjs_space`
4. Deploy

### Step 3: Run Migrations

```bash
# Connect to Railway
railway login

# Link project
railway link

# Run migrations
railway run yarn prisma db push
railway run yarn prisma db seed
```

## Option 4: Self-Hosted (VPS)

For AWS EC2, DigitalOcean, or other VPS:

### Step 1: Server Setup

```bash
# SSH into server
ssh user@your-server-ip

# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install Yarn
npm install -g yarn

# Install PM2
npm install -g pm2
```

### Step 2: Deploy Code

```bash
# Clone repository
git clone your-repo-url
cd your-repo/nextjs_space

# Install dependencies
yarn install

# Set up environment variables
nano .env
# Add all production environment variables

# Build application
yarn build

# Run migrations
yarn prisma generate
yarn prisma db push
yarn prisma db seed
```

### Step 3: Start Application

```bash
# Start with PM2
pm2 start yarn --name "ndis-template" -- start

# Save PM2 config
pm2 save

# Set up startup script
pm2 startup
```

### Step 4: Nginx Reverse Proxy

```bash
# Install Nginx
sudo apt install nginx

# Configure
sudo nano /etc/nginx/sites-available/ndis-template

# Add configuration:
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}

# Enable site
sudo ln -s /etc/nginx/sites-available/ndis-template /etc/nginx/sites-enabled/

# Test and restart
sudo nginx -t
sudo systemctl restart nginx
```

### Step 5: SSL Certificate

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d yourdomain.com

# Auto-renewal
sudo certbot renew --dry-run
```

## Post-Deployment Checklist

### Security

- [ ] Change default admin password
- [ ] Update NEXTAUTH_SECRET
- [ ] Enable HTTPS
- [ ] Configure CORS
- [ ] Set up rate limiting
- [ ] Review S3 bucket permissions

### Performance

- [ ] Enable CDN (Vercel/Netlify do this automatically)
- [ ] Optimize images
- [ ] Enable caching
- [ ] Monitor performance with Lighthouse

### Monitoring

- [ ] Set up error tracking (Sentry)
- [ ] Configure uptime monitoring
- [ ] Set up database backups
- [ ] Monitor server resources

### SEO

- [ ] Submit sitemap to Google Search Console
- [ ] Configure robots.txt
- [ ] Add Google Analytics
- [ ] Verify meta tags and OG images

### Testing

- [ ] Test all forms
- [ ] Test admin panel
- [ ] Test file uploads
- [ ] Test on multiple devices
- [ ] Test lead notifications
- [ ] Test payment flow (if using Stripe)

## Database Backups

### Automated Backups

**For Vercel Postgres:**
- Automatic daily backups included

**For Supabase:**
- Automatic daily backups on paid plans

**For Railway:**
```bash
# Manual backup
railway run pg_dump $DATABASE_URL > backup.sql

# Restore
railway run psql $DATABASE_URL < backup.sql
```

### Manual Backup Script

```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump $DATABASE_URL > backup_$DATE.sql
```

## Monitoring

### Uptime Monitoring

Free services:
- UptimeRobot
- StatusCake
- Pingdom (free tier)

### Error Tracking

**Sentry Integration:**

```bash
yarn add @sentry/nextjs
```

```typescript
// sentry.client.config.ts
import * as Sentry from "@sentry/nextjs";

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  tracesSampleRate: 1.0,
});
```

## Scaling

### Performance Optimization

1. **Database Indexing**
   - Already optimized in schema
   - Monitor slow queries

2. **Caching**
   - Use Redis for session storage
   - Cache API responses

3. **CDN**
   - Images automatically optimized by Next.js
   - Static assets served from CDN

### Load Balancing

For high traffic:
- Use multiple server instances
- Implement load balancer
- Use managed services (Vercel handles this)

## Troubleshooting

### Build Failures

```bash
# Clear cache
rm -rf .next node_modules
yarn install
yarn build
```

### Database Connection

```bash
# Test connection
yarn prisma studio

# Reset database (caution!)
yarn prisma db push --force-reset
```

### Environment Variables

Make sure all required variables are set:
```bash
# Check variables
vercel env ls

# Pull variables locally
vercel env pull
```

## Maintenance

### Updates

```bash
# Update dependencies
yarn upgrade-interactive --latest

# Test locally
yarn dev

# Deploy
git push origin main
```

### Database Migrations

```bash
# Create migration
yarn prisma migrate dev --name description

# Deploy to production
yarn prisma migrate deploy
```

## Support

If you encounter issues:

1. Check application logs
2. Review environment variables
3. Test database connection
4. Check API routes
5. Review security settings

## Success!

Your NDIS Template is now live! 🎉

Next steps:
- Monitor performance
- Collect user feedback
- Regular backups
- Security updates
- Content updates via admin panel

Remember to keep your dependencies updated and monitor your application regularly.
