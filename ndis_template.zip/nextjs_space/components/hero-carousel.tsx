
"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { CheckCircle, DollarSign, Clock } from "lucide-react";
import Link from "next/link";

const heroImages = [
  "/images/hero1_wheelchair_assistance.jpg",
  "/images/hero2_diverse_support_team.jpg",
  "/images/hero3_community_participation.jpg",
  "/images/hero4_accessible_home.jpg",
  "/images/hero5_consultation.jpg",
];

export function HeroCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) =>
        prevIndex === heroImages.length - 1 ? 0 : prevIndex + 1
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative h-[600px] md:h-[700px] overflow-hidden">
      {/* Background Image Carousel */}
      <AnimatePresence initial={false}>
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="absolute inset-0"
        >
          <div className="relative w-full h-full">
            <Image
              src={heroImages[currentIndex] ?? ""}
              alt={`NDIS Support Services ${currentIndex + 1}`}
              fill
              className="object-cover"
              priority={currentIndex === 0}
            />
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#660066]/90 to-[#660066]/70" />

      {/* Content */}
      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
        <div className="text-white max-w-3xl">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-4xl md:text-6xl font-bold mb-6 leading-tight"
          >
            NDIS Registration Made Easy — Fast, Guaranteed & Affordable
          </motion.h1>

          {/* Trust Badges */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8"
          >
            <Link 
              href="#testimonials"
              className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-lg p-3 transition-all hover:bg-white hover:text-gray-900 group cursor-pointer"
            >
              <CheckCircle className="h-6 w-6 text-green-400 group-hover:text-green-600 flex-shrink-0" />
              <span className="font-semibold">Trusted by 3000+ Providers</span>
            </Link>
            <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-lg p-3 transition-all hover:bg-white hover:text-gray-900 group">
              <DollarSign className="h-6 w-6 text-yellow-400 group-hover:text-yellow-600 flex-shrink-0" />
              <span className="font-semibold">Lowest Price</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-lg p-3 transition-all hover:bg-white hover:text-gray-900 group">
              <Clock className="h-6 w-6 text-blue-400 group-hover:text-blue-600 flex-shrink-0" />
              <span className="font-semibold">Docs in 24 Hours</span>
            </div>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <Button
              asChild
              size="lg"
              className="bg-white text-[#660066] hover:bg-gray-100 font-semibold text-lg px-8 py-6"
            >
              <Link href="#lead-form">Register Now</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="ghost"
              className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-[#660066] font-semibold text-lg px-8 py-6"
            >
              <Link href="#why-choose-us">Learn More</Link>
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Carousel Indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {heroImages.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentIndex
                ? "bg-white w-8"
                : "bg-white/50 hover:bg-white/75"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
}
