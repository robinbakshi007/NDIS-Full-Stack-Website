
"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Facebook, Linkedin, Instagram, Mail } from "lucide-react";

interface FooterSettings {
  logoUrl: string;
  acknowledgementText: string;
  facebookUrl: string;
  linkedinUrl: string;
  instagramUrl: string;
  companyEmail: string;
  phoneNumber: string;
}

export function Footer() {
  const [settings, setSettings] = useState<FooterSettings>({
    logoUrl: "/favicon.svg",
    acknowledgementText:
      "PRO CRM acknowledges the Traditional Custodians of the lands that we work on. We acknowledge the waterways, the land, the sky and all who inhabit these places. We acknowledge their ancestors, and Elders and recognise those who continue to protect and promote Aboriginal and Torres Strait Island cultures. We acknowledge the past and stand together for our future. PRO CRM celebrates diversity and all people.",
    facebookUrl: "",
    linkedinUrl: "",
    instagramUrl: "",
    companyEmail: "support@procrm.com",
    phoneNumber: "**** *** ***",
  });

  useEffect(() => {
    fetch("/api/settings?category=footer")
      .then((res) => res.json())
      .then((data) => {
        if (data.settings) {
          const footerSettings: any = {};
          data.settings.forEach((setting: any) => {
            footerSettings[setting.key] = setting.value;
          });
          setSettings((prev) => ({ ...prev, ...footerSettings }));
        }
      })
      .catch(console.error);
  }, []);

  const socialLinks = [
    {
      icon: Facebook,
      url: settings.facebookUrl,
      label: "Facebook",
      show: !!settings.facebookUrl,
    },
    {
      icon: Linkedin,
      url: settings.linkedinUrl,
      label: "LinkedIn",
      show: !!settings.linkedinUrl,
    },
    {
      icon: Instagram,
      url: settings.instagramUrl,
      label: "Instagram",
      show: !!settings.instagramUrl,
    },
  ];

  return (
    <footer className="bg-black text-white">
      {/* Top CTA Bar */}
      <div className="bg-white py-6 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-primary text-lg font-medium">
            Get a practitioner that's right for you
          </p>
          <Link href="/#lead-form">
            <button className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-8 py-3 rounded transition-colors">
              REFER NOW
            </button>
          </Link>
        </div>
      </div>

      {/* Purple Banner Section */}
      <div className="bg-[#660066] py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row items-center justify-between gap-6">
          <h3 className="text-white text-3xl md:text-4xl font-bold">
            Ready to Unlock{" "}
            <span className="text-orange-400">Fast, Effective</span> NDIS{" "}
            <span className="text-orange-400">Positive</span> Behaviour Support?
          </h3>
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="text-center sm:text-right">
              <p className="text-white text-sm mb-2">
                We'll be with you every step of the way.
              </p>
              <p className="text-white text-3xl font-bold">
                {settings.phoneNumber}
              </p>
            </div>
            <Link href="/#lead-form">
              <button className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-8 py-3 rounded transition-colors whitespace-nowrap">
                REFER NOW
              </button>
            </Link>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="bg-black py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {/* Logo and Social Links */}
            <div className="space-y-6">
              <div className="relative h-24 w-48">
                <Image
                  src={settings.logoUrl}
                  alt="Company Logo"
                  fill
                  className="object-contain object-left"
                  priority
                />
              </div>

              {/* Social Media Links */}
              <div className="flex space-x-4">
                {socialLinks.map(
                  (social) =>
                    social.show && (
                      <a
                        key={social.label}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-white/10 hover:bg-white/20 rounded-full p-3 transition-colors"
                        aria-label={social.label}
                      >
                        <social.icon className="h-5 w-5 text-white" />
                      </a>
                    )
                )}
              </div>


            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-orange-400 font-semibold text-lg mb-6 uppercase">
                Quick Links
              </h4>
              <ul className="space-y-3">
                <li>
                  <Link
                    href="/#services"
                    className="text-white hover:text-orange-400 transition-colors"
                  >
                    Services
                  </Link>
                </li>
                <li>
                  <Link
                    href="/about"
                    className="text-white hover:text-orange-400 transition-colors"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    href="/contact"
                    className="text-white hover:text-orange-400 transition-colors"
                  >
                    Contact
                  </Link>
                </li>
                <li>
                  <Link
                    href="/#faq"
                    className="text-white hover:text-orange-400 transition-colors"
                  >
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>

            {/* Other Pages */}
            <div>
              <h4 className="text-orange-400 font-semibold text-lg mb-6 uppercase">
                Other Pages
              </h4>
              <ul className="space-y-3">
                <li>
                  <Link
                    href="/contact"
                    className="text-white hover:text-orange-400 transition-colors"
                  >
                    Feedback
                  </Link>
                </li>
                <li>
                  <Link
                    href="/privacy"
                    className="text-white hover:text-orange-400 transition-colors"
                  >
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="text-orange-400 font-semibold text-lg mb-6 uppercase">
                Contact
              </h4>
              <ul className="space-y-3">
                <li>
                  <a
                    href={`tel:${settings.phoneNumber.replace(/\s/g, "")}`}
                    className="text-white hover:text-orange-400 transition-colors"
                  >
                    {settings.phoneNumber}
                  </a>
                </li>
                <li>
                  <a
                    href={`mailto:${settings.companyEmail}`}
                    className="text-white hover:text-orange-400 transition-colors break-all"
                  >
                    {settings.companyEmail}
                  </a>
                </li>
              </ul>

              {/* Newsletter */}
              <div className="mt-8">
                <h4 className="text-orange-400 font-semibold text-lg mb-4 uppercase">
                  Newsletter
                </h4>
                <form className="flex gap-2">
                  <input
                    type="email"
                    placeholder="EMAIL"
                    className="bg-white/10 border border-white/20 rounded px-4 py-2 text-white placeholder-white/50 flex-1"
                  />
                  <button
                    type="submit"
                    className="bg-orange-500 hover:bg-orange-600 text-white font-semibold px-6 py-2 rounded transition-colors"
                  >
                    SEND
                  </button>
                </form>
              </div>
            </div>
          </div>

          {/* NDIS Provider Badge - Right Side */}
          <div className="mt-12 flex justify-end">
            <div className="bg-primary p-4 rounded-lg">
              <p className="text-white text-sm font-semibold text-center">
                NDIS
                <br />
                REGISTERED
                <br />
                PROVIDER
              </p>
            </div>
          </div>

          {/* Acknowledgement Text */}
          <div className="mt-12 pt-8 border-t border-white/20">
            <p className="text-white/80 text-sm leading-relaxed">
              {settings.acknowledgementText}
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="bg-black py-4 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-white/70 text-sm">
            © {new Date().getFullYear()} All Rights Reserved | Powered by{" "}
            <span className="text-orange-400 font-semibold">PRO CRM</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
