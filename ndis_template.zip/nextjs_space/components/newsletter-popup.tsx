'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mail, Send, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

export function NewsletterPopup() {
  const [showPopup, setShowPopup] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    mobile: '',
    serviceType: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    // Check if user has already seen the popup in this session
    const popupShown = sessionStorage.getItem('newsletterPopupShown');
    
    if (!popupShown) {
      const timer = setTimeout(() => {
        setShowPopup(true);
        sessionStorage.setItem('newsletterPopupShown', 'true');
      }, 10000); // 10 seconds

      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    setShowPopup(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        setSubmitted(true);
        toast.success('Thank you! We\'ll be in touch soon.');
        setTimeout(() => {
          handleClose();
        }, 2000);
      } else {
        toast.error('Something went wrong. Please try again.');
      }
    } catch (error) {
      toast.error('Failed to submit. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {showPopup && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', duration: 0.5 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="relative bg-white rounded-2xl shadow-2xl max-w-5xl w-full max-h-[90vh] overflow-y-auto">
              {/* Close button */}
              <button
                onClick={handleClose}
                className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors z-10 bg-white shadow-md"
                aria-label="Close popup"
              >
                <X className="w-6 h-6 text-gray-700 hover:text-gray-900" />
              </button>

              {!submitted ? (
                <div className="grid md:grid-cols-2 gap-0">
                  {/* Left Column - Newsletter Signup */}
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                    className="bg-gradient-to-br from-purple-600 to-blue-600 p-8 md:p-12 text-white rounded-l-2xl flex flex-col justify-center"
                  >
                    <Mail className="w-16 h-16 mb-6 animate-bounce" />
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">
                      Stay Informed!
                    </h2>
                    <p className="text-lg mb-6 text-purple-100">
                      Get expert NDIS guidance and updates delivered to your inbox.
                    </p>
                    
                    <div className="space-y-4">
                      <div className="flex items-start space-x-3">
                        <CheckCircle2 className="w-6 h-6 text-green-300 flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold text-lg">No Spam, Ever</h3>
                          <p className="text-purple-100 text-sm">We respect your inbox and privacy</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <CheckCircle2 className="w-6 h-6 text-green-300 flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold text-lg">Expert Tips</h3>
                          <p className="text-purple-100 text-sm">NDIS registration insights and updates</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <CheckCircle2 className="w-6 h-6 text-green-300 flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold text-lg">Free Resources</h3>
                          <p className="text-purple-100 text-sm">Guides, checklists, and templates</p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-lg">
                      <p className="text-sm text-purple-100">
                        <strong>Join 3,000+ providers</strong> who trust us for their NDIS journey
                      </p>
                    </div>
                  </motion.div>

                  {/* Right Column - Contact Form */}
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 }}
                    className="p-8 md:p-12"
                  >
                    <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                      Get Started Today
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Fill out the form below and we'll be in touch within 24 hours
                    </p>

                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div>
                        <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                          First Name <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="firstName"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleChange}
                          placeholder="John"
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                        />
                      </div>

                      <div>
                        <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                          Last Name <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="lastName"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleChange}
                          placeholder="Doe"
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                        />
                      </div>

                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                          Email <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          placeholder="john@example.com"
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                        />
                      </div>

                      <div>
                        <label htmlFor="mobile" className="block text-sm font-medium text-gray-700 mb-1">
                          Mobile <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="tel"
                          id="mobile"
                          name="mobile"
                          value={formData.mobile}
                          onChange={handleChange}
                          placeholder="04XX XXX XXX"
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                        />
                      </div>

                      <div>
                        <label htmlFor="serviceType" className="block text-sm font-medium text-gray-700 mb-1">
                          Service Type <span className="text-red-500">*</span>
                        </label>
                        <select
                          id="serviceType"
                          name="serviceType"
                          value={formData.serviceType}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                        >
                          <option value="">Select a service type</option>
                          <option value="Assistance with Daily Life">Assistance with Daily Life</option>
                          <option value="Community Participation">Community Participation</option>
                          <option value="Therapeutic Supports">Therapeutic Supports</option>
                          <option value="Supported Independent Living">Supported Independent Living</option>
                          <option value="Plan Management">Plan Management</option>
                          <option value="Support Coordination">Support Coordination</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>

                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                      >
                        {isSubmitting ? (
                          <>
                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            <span>Sending...</span>
                          </>
                        ) : (
                          <>
                            <Send className="w-5 h-5" />
                            <span>Get Free Consultation</span>
                          </>
                        )}
                      </button>
                    </form>

                    <p className="text-xs text-gray-500 mt-4 text-center">
                      By submitting, you agree to receive emails from us. Unsubscribe anytime.
                    </p>
                  </motion.div>
                </div>
              ) : (
                // Success State
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-12 text-center"
                >
                  <CheckCircle2 className="w-20 h-20 text-green-500 mx-auto mb-6 animate-bounce" />
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">
                    Thank You!
                  </h2>
                  <p className="text-lg text-gray-600 mb-2">
                    We've received your information and will be in touch within 24 hours.
                  </p>
                  <p className="text-sm text-gray-500">
                    Check your email for our welcome message!
                  </p>
                </motion.div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
