
"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Users, Star, TrendingUp } from "lucide-react";

const statistics = [
  {
    icon: Users,
    value: 3000,
    displayValue: "3,000+",
    label: "Registrations Supported",
    suffix: "+",
    showStars: false
  },
  {
    icon: Star,
    value: 5,
    displayValue: "5",
    label: "Stars Happy Clients",
    suffix: "",
    showStars: true
  },
  {
    icon: TrendingUp,
    value: 100,
    displayValue: "100%",
    label: "Success Rate",
    suffix: "%",
    showStars: false
  }
];

function Counter({ displayValue, value, suffix, showStars }: { displayValue: string; value: number; suffix: string; showStars: boolean }) {
  const [count, setCount] = useState(0);
  const [hasAnimated, setHasAnimated] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && !hasAnimated) {
          setHasAnimated(true);
          const duration = 2000;
          const steps = 60;
          const increment = value / steps;
          let current = 0;

          const timer = setInterval(() => {
            current += increment;
            if (current >= value) {
              setCount(value);
              clearInterval(timer);
            } else {
              setCount(Math.floor(current));
            }
          }, duration / steps);

          return () => clearInterval(timer);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [value, hasAnimated]);

  // Format the displayed count
  const formatCount = () => {
    if (!hasAnimated) return displayValue.replace(/\d/g, '0');
    if (count === value) return displayValue;
    
    // During animation, show the count without formatting
    if (suffix === "+") return `${count.toLocaleString()}+`;
    if (suffix === "%") return `${count}%`;
    return count.toString();
  };

  return (
    <div 
      ref={ref} 
      className="text-5xl font-bold text-primary"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {showStars && count === value ? (
        <div className="flex items-center justify-center gap-1">
          {[...Array(5)].map((_, i) => (
            <Star 
              key={i} 
              className={`h-10 w-10 transition-all ${
                isHovered 
                  ? 'fill-yellow-400 text-yellow-400 scale-110' 
                  : 'fill-yellow-400 text-yellow-400'
              }`}
            />
          ))}
        </div>
      ) : (
        formatCount()
      )}
    </div>
  );
}

export function StatisticsBar() {
  return (
    <section className="bg-gradient-to-r from-primary/10 to-primary/5 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {statistics.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="text-center"
            >
              <div className="flex justify-center mb-4">
                <div className="bg-white rounded-full p-4 shadow-lg">
                  <stat.icon className={`h-8 w-8 ${stat.showStars ? 'text-yellow-400' : 'text-primary'}`} />
                </div>
              </div>
              <Counter 
                displayValue={stat.displayValue}
                value={stat.value} 
                suffix={stat.suffix} 
                showStars={stat.showStars}
              />
              <p className="text-gray-600 font-medium mt-2">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
