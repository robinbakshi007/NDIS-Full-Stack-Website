
"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import Link from "next/link";

interface PricingPackage {
  id: string;
  name: string;
  currentPrice: number;
  originalPrice: number;
  description: string;
  features: string[];
  visible: boolean;
}

export function PricingCards() {
  const [packages, setPackages] = useState<PricingPackage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/pricing")
      .then((res) => res.json())
      .then((data) => {
        setPackages(data ?? []);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching pricing:", error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <section className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-600">Loading pricing...</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="pricing" className="py-20 bg-gradient-to-br from-primary/5 to-primary/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            NDIS Registration Packages
          </h2>
          <p className="text-xl text-gray-600">
            Choose the package that best fits your needs
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {packages.map((pkg, index) => (
            <motion.div
              key={pkg.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-shadow duration-300 p-8 flex flex-col"
            >
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  {pkg.name}
                </h3>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-purple-600">
                    ${pkg.currentPrice}
                  </div>
                  <div className="text-gray-500 line-through">
                    ${pkg.originalPrice}
                  </div>
                </div>
              </div>

              {pkg.description && (
                <p className="text-gray-600 text-sm mb-6 text-center">
                  {pkg.description}
                </p>
              )}

              <ul className="space-y-3 mb-8 flex-grow">
                {Array.isArray(pkg.features) &&
                  pkg.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </li>
                  ))}
              </ul>

              <Button
                asChild
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold"
              >
                <Link href="#lead-form">Get Registered</Link>
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
