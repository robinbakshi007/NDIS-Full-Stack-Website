
"use client";

import { motion } from "framer-motion";
import { ClipboardCheck, FileText, Phone, Clock, Users, CheckCircle2 } from "lucide-react";

const steps = [
  {
    number: 1,
    icon: ClipboardCheck,
    title: "Check Your Eligibility",
    description:
      "Ensure you meet the requirements, which include being under 65, an Australian citizen or permanent resident, and having a permanent and significant disability.",
  },
  {
    number: 2,
    icon: FileText,
    title: "Gather Information and Documentation",
    description:
      "Collect documents that support your application, such as medical reports, assessments, and proof of identity.",
  },
  {
    number: 3,
    icon: Phone,
    title: "Contact the NDIS and Submit Your Request",
    description:
      "Call the NDIS on 1800 800 110 to request an Access Request Form, visit your local NDIS office, or download the form from the NDIS website. Submit the completed form along with all your supporting documents.",
  },
  {
    number: 4,
    icon: Clock,
    title: "Wait for a Decision",
    description:
      "The NDIS will review your application and evidence, and a decision is typically made within 21 days of receiving all necessary information.",
  },
  {
    number: 5,
    icon: Users,
    title: "Attend a Planning Meeting (if approved)",
    description:
      "If your application is successful, you will schedule a planning meeting with an NDIS planner. This meeting is where you will discuss your goals and needs to create your NDIS plan.",
  },
  {
    number: 6,
    icon: CheckCircle2,
    title: "Receive and Implement Your Plan",
    description:
      "Once the planning meeting is complete, you will receive your NDIS plan, which outlines your supports and funding. You can then use your plan to access services from providers.",
  },
];

export function ProcessSteps() {
  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            How to Apply for NDIS Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            To apply for NDIS services, follow these steps to complete your Access Request Form and create your personalized support plan.
          </p>
        </motion.div>

        <div className="relative">
          {/* Timeline line - vertical on mobile, horizontal on desktop */}
          <div className="hidden lg:block absolute top-20 left-0 right-0 h-1 bg-gradient-to-r from-purple-300 via-blue-300 to-indigo-300" />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="relative"
              >
                {/* Step number circle */}
                <div className="flex justify-center mb-6">
                  <div className="relative">
                    <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-full w-20 h-20 flex items-center justify-center shadow-lg z-10 relative">
                      <step.icon className="h-10 w-10 text-white" />
                    </div>
                    <div className="absolute -top-2 -right-2 bg-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-purple-600 shadow-md z-20">
                      {step.number}
                    </div>
                  </div>
                </div>

                {/* Content card */}
                <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300 h-full">
                  <h3 className="text-xl font-bold text-gray-900 mb-3 text-center">
                    {step.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed text-center">
                    {step.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Additional Information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-[14rem] bg-indigo-50 rounded-2xl p-8 text-center shadow-lg"
        >
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Need Help with Your Application?
          </h3>
          <p className="text-gray-700 text-lg mb-6 max-w-3xl mx-auto">
            Our team is here to support you through every step of the NDIS application process. 
            Contact us for personalized guidance and assistance.
          </p>
          <a
            href="/#lead-form"
            className="inline-block bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold px-8 py-3 rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            Get Started Today
          </a>
        </motion.div>
      </div>
    </section>
  );
}
