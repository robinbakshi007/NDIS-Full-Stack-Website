
"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle, Users, Award, Clock, TrendingUp, Heart, UserCheck, Lightbulb } from "lucide-react";
import Image from "next/image";
import { ChevronLeft, ChevronRight } from "lucide-react";

const benefits = [
  {
    id: 1,
    title: "Personalised Approach",
    description:
      "Our Positive Behavioural Support (PBS) services are tailored to meet the unique needs of each individual, ensuring a customized and effective support plan.",
    icon: UserCheck,
    color: "#FF6B6B",
  },
  {
    id: 2,
    title: "Experienced Professionals",
    description:
      "Our team consists of highly experienced psychologists, therapists & support workers, dedicated to helping individuals develop reach their full potential.",
    icon: Award,
    color: "#4ECDC4",
  },
  {
    id: 3,
    title: "Flexible Service Options",
    description:
      "We offer a variety of service delivery options, including in-person, online & hybrid models, to accommodate the diverse needs & schedules of our clients.",
    icon: Clock,
    color: "#FFD93D",
  },
  {
    id: 4,
    title: "Ongoing Progress Monitoring",
    description:
      "Our services include regular progress assessments, allowing us to adapt and refine our support strategies as needed to ensure continued growth and success.",
    icon: TrendingUp,
    color: "#A8E6CF",
  },
  {
    id: 5,
    title: "Evidence-Based Techniques",
    description:
      "We use proven, research-backed strategies to design our PBS programs, ensuring our clients receive the most effective support possible.",
    icon: CheckCircle,
    color: "#9B59B6",
  },
  {
    id: 6,
    title: "Inclusive Environment",
    description:
      "We are committed to fostering a safe, inclusive and respectful space for individuals of all backgrounds, abilities & support needs.",
    icon: Heart,
    color: "#FF8B94",
  },
  {
    id: 7,
    title: "Family Collaboration",
    description:
      "We work closely with families and caregivers, to provide them with the tools, resources, and necessary knowledge to help their loved ones succeed.",
    icon: Users,
    color: "#6C5CE7",
  },
  {
    id: 8,
    title: "Skill-Building Workshops",
    description:
      "In addition to one-on-one support, we offer group workshops and training sessions to help individuals build essential life skills and strengthen their social networks.",
    icon: Lightbulb,
    color: "#FFA500",
  },
];

const carouselImages = [
  "/images/personalized_support.jpg",
  "/images/therapist_session.jpg",
  "/images/ndis_audit_verification.jpg",
  "/images/support_team_collaboration.jpg",
];

export function BenefitsCarousel() {
  const [currentBenefitIndex, setCurrentBenefitIndex] = useState(0);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Auto-rotate benefits every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBenefitIndex((prev) => (prev + 1) % benefits.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Auto-rotate images every 4 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % carouselImages.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const currentBenefit = benefits[currentBenefitIndex];
  const IconComponent = currentBenefit.icon;

  const nextBenefit = () => {
    setCurrentBenefitIndex((prev) => (prev + 1) % benefits.length);
  };

  const prevBenefit = () => {
    setCurrentBenefitIndex((prev) => (prev - 1 + benefits.length) % benefits.length);
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            The Benefits of Choosing Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover why families and individuals trust us for their NDIS support needs
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Image Carousel */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentImageIndex}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  className="absolute inset-0"
                >
                  <Image
                    src={carouselImages[currentImageIndex]}
                    alt="NDIS Support Services"
                    fill
                    className="object-cover"
                    loading="lazy"
                  />
                </motion.div>
              </AnimatePresence>

              {/* Carousel Indicators */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2 z-10">
                {carouselImages.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`h-2 rounded-full transition-all ${
                      index === currentImageIndex
                        ? "w-8 bg-white"
                        : "w-2 bg-white/50 hover:bg-white/70"
                    }`}
                    aria-label={`Go to image ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </motion.div>

          {/* Right Column - Text Carousel */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 border-2 border-gray-100 min-h-[400px] flex flex-col justify-center">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentBenefitIndex}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.5 }}
                >
                  {/* Icon */}
                  <div className="mb-6">
                    <div
                      className="inline-flex items-center justify-center w-16 h-16 rounded-xl"
                      style={{ backgroundColor: `${currentBenefit.color}20` }}
                    >
                      <IconComponent
                        className="w-8 h-8"
                        style={{ color: currentBenefit.color }}
                      />
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-3xl font-bold text-gray-900 mb-4">
                    {currentBenefit.title}
                  </h3>

                  {/* Description */}
                  <p className="text-lg text-gray-600 leading-relaxed mb-8">
                    {currentBenefit.description}
                  </p>

                  {/* Progress Indicator */}
                  <div className="flex items-center justify-between">
                    <div className="flex space-x-2">
                      {benefits.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentBenefitIndex(index)}
                          className={`h-2 rounded-full transition-all ${
                            index === currentBenefitIndex
                              ? "w-8 bg-primary"
                              : "w-2 bg-gray-300 hover:bg-gray-400"
                          }`}
                          aria-label={`Go to benefit ${index + 1}`}
                        />
                      ))}
                    </div>

                    {/* Navigation Arrows */}
                    <div className="flex space-x-2">
                      <button
                        onClick={prevBenefit}
                        className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
                        aria-label="Previous benefit"
                      >
                        <ChevronLeft className="w-5 h-5 text-gray-700" />
                      </button>
                      <button
                        onClick={nextBenefit}
                        className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
                        aria-label="Next benefit"
                      >
                        <ChevronRight className="w-5 h-5 text-gray-700" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
