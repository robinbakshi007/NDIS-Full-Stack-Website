
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SERVICE_TYPES } from "@/lib/constants";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Send, CheckCircle, Award, Clock } from "lucide-react";
import Image from "next/image";

export function LeadFormBottom() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    mobile: "",
    serviceType: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Failed to submit form");
      }

      toast.success("Thank you! We'll contact you soon.");
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        mobile: "",
        serviceType: "",
      });
    } catch (error) {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="lead-form" className="relative py-0 overflow-hidden">
      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[700px]">
        {/* Left Column - Background Image */}
        <div className="relative hidden lg:block">
          <div className="absolute inset-0">
            <Image
              src="/images/hero5_consultation.jpg"
              alt="NDIS Consultation"
              fill
              className="object-cover"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary/70" />
          
          {/* Overlay Content */}
          <div className="relative h-full flex flex-col justify-center px-12 text-white">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h3 className="text-4xl font-bold mb-6">
                Why Choose Our NDIS Registration Services?
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-white/20 rounded-lg p-3 mt-1">
                    <CheckCircle className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold mb-2">100% Success Rate</h4>
                    <p className="text-white/90">
                      Every client we've worked with has successfully achieved NDIS registration. Our proven process ensures your approval.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-white/20 rounded-lg p-3 mt-1">
                    <Clock className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold mb-2">Fast Turnaround</h4>
                    <p className="text-white/90">
                      Receive your complete audit-ready documentation within 24 hours. Start delivering services sooner.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-white/20 rounded-lg p-3 mt-1">
                    <Award className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold mb-2">Expert Support</h4>
                    <p className="text-white/90">
                      Trusted by 3,000+ providers across Australia. Our experienced team guides you every step of the way.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Right Column - White Card with Form */}
        <div className="flex items-center justify-center bg-gray-50 px-6 py-12 lg:px-12">
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="w-full max-w-xl"
          >
            <div className="bg-white rounded-2xl shadow-2xl p-8 lg:p-10">
              <div className="text-center mb-8">
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
                  Get NDIS Registered Today!
                </h2>
                <p className="text-lg text-gray-600">
                  Fill out the form below and receive instant access to audit-ready documentation
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName-bottom" className="text-gray-700 font-medium">
                      First Name *
                    </Label>
                    <Input
                      id="firstName-bottom"
                      required
                      value={formData.firstName}
                      onChange={(e) =>
                        setFormData({ ...formData, firstName: e.target.value })
                      }
                      className="mt-1"
                      placeholder="John"
                    />
                  </div>

                  <div>
                    <Label htmlFor="lastName-bottom" className="text-gray-700 font-medium">
                      Last Name *
                    </Label>
                    <Input
                      id="lastName-bottom"
                      required
                      value={formData.lastName}
                      onChange={(e) =>
                        setFormData({ ...formData, lastName: e.target.value })
                      }
                      className="mt-1"
                      placeholder="Doe"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email-bottom" className="text-gray-700 font-medium">
                    Email *
                  </Label>
                  <Input
                    id="email-bottom"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    className="mt-1"
                    placeholder="john@example.com"
                  />
                </div>

                <div>
                  <Label htmlFor="mobile-bottom" className="text-gray-700 font-medium">
                    Mobile *
                  </Label>
                  <Input
                    id="mobile-bottom"
                    type="tel"
                    required
                    value={formData.mobile}
                    onChange={(e) =>
                      setFormData({ ...formData, mobile: e.target.value })
                    }
                    className="mt-1"
                    placeholder="04XX XXX XXX"
                  />
                </div>

                <div>
                  <Label htmlFor="serviceType-bottom" className="text-gray-700 font-medium">
                    Service Type *
                  </Label>
                  <Select
                    required
                    value={formData.serviceType}
                    onValueChange={(value) =>
                      setFormData({ ...formData, serviceType: value })
                    }
                  >
                    <SelectTrigger id="serviceType-bottom" className="mt-1">
                      <SelectValue placeholder="Select a service type" />
                    </SelectTrigger>
                    <SelectContent>
                      {SERVICE_TYPES.map((service) => (
                        <SelectItem key={service} value={service}>
                          {service}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-primary hover:bg-primary/90 text-white font-semibold py-6 text-lg"
                >
                  {isSubmitting ? (
                    "Submitting..."
                  ) : (
                    <>
                      <Send className="mr-2 h-5 w-5" />
                      Get Started Now
                    </>
                  )}
                </Button>

                <p className="text-sm text-center text-gray-500">
                  By submitting this form, you agree to our Terms & Conditions
                </p>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
