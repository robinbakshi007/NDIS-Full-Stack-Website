
"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle, Clock, Users } from "lucide-react";
import Image from "next/image";

const benefits = [
  {
    icon: CheckCircle,
    title: "100% Success Rate",
    description:
      "Every client we've worked with has successfully achieved NDIS registration. Our proven process ensures your approval.",
    image: "/images/success_rate_celebration.jpg",
  },
  {
    icon: Clock,
    title: "Fast Turnaround",
    description:
      "Receive your complete audit-ready documentation within 24 hours. Start delivering services sooner.",
    image: "/images/fast_turnaround_24hrs.jpg",
  },
  {
    icon: Users,
    title: "Expert Support",
    description:
      "Trusted by 3,000+ providers across Australia. Our experienced team guides you every step of the way.",
    image: "/images/expert_consultation_support.jpg",
  },
];

export function WhyChooseUs() {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto-rotate images every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % benefits.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="why-choose-us" className="py-20 relative overflow-hidden">
      {/* Purple-Blue Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-700 via-purple-600 to-blue-600" />
      
      {/* Background Pattern Overlay */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='https://placehold.co/1200x600/e2e8f0/1e293b?text=a_small_repeating_white_geometric_SVG_background_p fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/svg%3E")`,
        }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Why Choose Our NDIS Registration Services?
          </h2>
        </motion.div>

        {/* Image Carousel with Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          {/* Left Side - Image Carousel */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative aspect-video rounded-2xl overflow-hidden shadow-2xl">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentIndex}
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.7 }}
                  className="relative w-full h-full"
                >
                  <Image
                    src={benefits[currentIndex]?.image ?? ""}
                    alt={benefits[currentIndex]?.title ?? "NDIS Services"}
                    fill
                    className="object-cover"
                    priority={currentIndex === 0}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                </motion.div>
              </AnimatePresence>

              {/* Carousel Indicators */}
              <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex space-x-3 z-10">
                {benefits.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`h-3 rounded-full transition-all duration-300 ${
                      index === currentIndex
                        ? "w-12 bg-white"
                        : "w-3 bg-white/50 hover:bg-white/75"
                    }`}
                    aria-label={`Go to slide ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </motion.div>

          {/* Right Side - Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20"
              >
                {/* Icon */}
                <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-6">
                  {benefits[currentIndex] && (() => {
                    const IconComponent = benefits[currentIndex].icon;
                    return <IconComponent className="h-8 w-8 text-white" />;
                  })()}
                </div>

                {/* Title */}
                <h3 className="text-3xl font-bold text-white mb-4">
                  {benefits[currentIndex]?.title}
                </h3>

                {/* Description */}
                <p className="text-white/90 text-lg leading-relaxed">
                  {benefits[currentIndex]?.description}
                </p>
              </motion.div>
            </AnimatePresence>

            {/* All Benefits Summary */}
            <div className="grid grid-cols-3 gap-4">
              {benefits.map((benefit, index) => (
                <motion.button
                  key={benefit.title}
                  onClick={() => setCurrentIndex(index)}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    index === currentIndex
                      ? "bg-white/20 border-2 border-white shadow-lg"
                      : "bg-white/5 border border-white/20 hover:bg-white/10"
                  }`}
                >
                  <benefit.icon
                    className={`h-6 w-6 mx-auto mb-2 transition-colors duration-300 ${
                      index === currentIndex ? "text-white" : "text-white/70"
                    }`}
                  />
                  <p
                    className={`text-sm font-semibold transition-colors duration-300 ${
                      index === currentIndex ? "text-white" : "text-white/70"
                    }`}
                  >
                    {benefit.title}
                  </p>
                </motion.button>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
