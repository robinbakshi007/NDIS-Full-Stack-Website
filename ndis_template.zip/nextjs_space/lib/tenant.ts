import { prisma } from './db';

/**
 * Get tenant from subdomain
 */
export async function getTenantBySubdomain(subdomain: string) {
  return await prisma.tenant.findUnique({
    where: { subdomain },
    include: {
      users: true,
    },
  });
}

/**
 * Get tenant from request headers
 */
export function getSubdomainFromHost(host: string | null): string | null {
  if (!host) return null;
  
  // Remove port if present
  const hostname = host.split(':')[0];
  
  // Split by dots
  const parts = hostname.split('.');
  
  // If localhost or IP, no subdomain
  if (hostname === 'localhost' || /^\d+\.\d+\.\d+\.\d+$/.test(hostname)) {
    return null;
  }
  
  // If we have at least 3 parts (subdomain.domain.tld), extract subdomain
  if (parts.length >= 3) {
    return parts[0];
  }
  
  return null;
}

/**
 * Check if tenant is active and subscription is valid
 */
export async function isTenantActive(tenantId: string): Promise<boolean> {
  const tenant = await prisma.tenant.findUnique({
    where: { id: tenantId },
  });
  
  if (!tenant) return false;
  if (tenant.status !== 'active') return false;
  
  // Check subscription status
  const validStatuses = ['active', 'trialing'];
  if (tenant.subscriptionStatus && !validStatuses.includes(tenant.subscriptionStatus)) {
    return false;
  }
  
  return true;
}
