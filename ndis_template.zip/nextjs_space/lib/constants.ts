
export const SERVICE_TYPES = [
  "Allied Health & Therapy",
  "Assistive Technology",
  "Behaviour Support Practitioner",
  "Building & Trades",
  "Cleaning",
  "Community Participation",
  "Developmental Educator",
  "Driving Instructor",
  "Early Intervention Support",
  "Exercise Physiologist",
  "Gardening",
  "General House Maintenance",
  "Group Activities",
  "Home Modifications",
  "Interpreter/Translator",
  "Meal Preparation",
  "Mechanic",
  "Nursing",
  "Personal Training",
  "Plan Management",
  "Products",
  "Recovery Coaches",
  "Short-Term Accommodation (Respite)",
  "Social Work",
  "Specialist Disability Accommodation (SDA)",
  "Support Coordinator",
  "Support Work",
  "Supported Independent Living (SIL)",
  "Travel & Transport (Driving)",
  "Vehicle Modifications"
];

export const LEAD_STATUSES = [
  "new",
  "contacted",
  "qualified",
  "converted",
  "unqualified"
];
