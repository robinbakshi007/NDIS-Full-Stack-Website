
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Starting database seed...");

  // Create admin user
  const hashedPassword = await bcrypt.hash("admin123", 10);
  
  const adminUser = await prisma.user.upsert({
    where: { email: "admin@ndis.com" },
    update: {},
    create: {
      email: "admin@ndis.com",
      password: hashedPassword,
      name: "Admin User",
      role: "admin",
    },
  });
  console.log("✅ Admin user created:", adminUser.email);

  // Create test user (for testing purposes)
  const testHashedPassword = await bcrypt.hash("johndoe123", 10);
  
  const testUser = await prisma.user.upsert({
    where: { email: "john@doe.com" },
    update: {},
    create: {
      email: "john@doe.com",
      password: testHashedPassword,
      name: "John Doe",
      role: "admin",
    },
  });
  console.log("✅ Test user created:", testUser.email);

  // Create testimonials
  const testimonials = [
    {
      name: "Joansy King",
      company: "Disability Support Services",
      quote: "EnableUs provided invaluable assistance in navigating complex processes. I highly recommend their services to individuals and organisations seeking expert guidance and support.",
      photoUrl: "https://cdn.abacus.ai/images/3ecc94c6-300b-44a4-accd-77fb896a5ee3.png",
      orderPosition: 0,
    },
    {
      name: "Lauren Cockburn",
      company: "Community Care Provider",
      quote: "EnableUs was an extremely professional service, the communication and guidance was excellent. I would highly recommend this company.",
      photoUrl: "https://cdn.abacus.ai/images/4151e406-a854-4a97-986c-c4f13ed18812.png",
      orderPosition: 1,
    },
    {
      name: "Cheryl Tilsed",
      company: "Support Coordination Services",
      quote: "Excellent service from start to finish from EnableUs. Trustworthy, supportive and supply all the information needed to help you in the process of becoming NDIS approved! I totally recommend using EnableUs",
      photoUrl: "https://cdn.abacus.ai/images/bf6612bb-8cc0-4e6a-b700-16e7aa78130f.png",
      orderPosition: 2,
    },
    {
      name: "Rahul Verma",
      company: "Allied Health Services",
      quote: "I would definitely recommend EnableUs to anyone needing real support. Their expertise in NDIS registration made the entire process seamless.",
      photoUrl: "https://cdn.abacus.ai/images/ba5f26bb-ec56-455a-a6fa-89842063e0e1.png",
      orderPosition: 3,
    },
    {
      name: "Michael Trusso",
      company: "Home Care Services",
      quote: "EnableUs played a pivotal role in my NDIS journey. Their assistance made all the difference, and I'm truly grateful.",
      photoUrl: "https://cdn.abacus.ai/images/2e961db6-80bc-4242-983e-8e27baa4957c.png",
      orderPosition: 4,
    },
    {
      name: "Shamina Najmudeen",
      company: "Therapy Services",
      quote: "I am glad I found EnableUs to assist me with my NDIS application process. I will choose them again.",
      photoUrl: "https://cdn.abacus.ai/images/6e18f5e6-a75f-43d5-9119-a00558ab0a5c.png",
      orderPosition: 5,
    },
  ];

  for (const testimonial of testimonials) {
    await prisma.testimonial.upsert({
      where: { id: `testimonial-${testimonial.orderPosition}` },
      update: testimonial,
      create: {
        id: `testimonial-${testimonial.orderPosition}`,
        ...testimonial,
      },
    });
  }
  console.log("✅ Testimonials created:", testimonials.length);

  // Create pricing packages
  const pricingPackages = [
    {
      id: "verification-module",
      name: "Verification Module",
      currentPrice: 899,
      originalPrice: 1499,
      description: "Perfect for low-risk services",
      features: [
        "Customised documentation",
        "NDIS application support",
        "Email support",
        "24-hour document delivery",
        "100% audit ready",
      ],
      orderPosition: 0,
    },
    {
      id: "core-module",
      name: "Core Module",
      currentPrice: 1999,
      originalPrice: 3330,
      description: "Ideal for medium-risk services",
      features: [
        "Everything in Verification",
        "Priority support",
        "Phone consultation",
        "Audit preparation assistance",
        "Ongoing compliance support",
      ],
      orderPosition: 1,
    },
    {
      id: "specialist-module",
      name: "Specialist Module",
      currentPrice: 2499,
      originalPrice: 4165,
      description: "Comprehensive high-risk coverage",
      features: [
        "Everything in Core",
        "Dedicated account manager",
        "Advanced documentation",
        "Full audit support",
        "Post-approval guidance",
      ],
      orderPosition: 2,
    },
    {
      id: "sda-module",
      name: "SDA Module",
      currentPrice: 1099,
      originalPrice: 1830,
      description: "Specialist disability accommodation",
      features: [
        "SDA-specific documentation",
        "Property compliance review",
        "Design category guidance",
        "NDIS SDA requirements",
        "Ongoing SDA support",
      ],
      orderPosition: 3,
    },
  ];

  for (const pkg of pricingPackages) {
    await prisma.pricingPackage.upsert({
      where: { id: pkg.id },
      update: pkg,
      create: pkg,
    });
  }
  console.log("✅ Pricing packages created:", pricingPackages.length);

  // Create FAQs
  const faqs = [
    {
      id: "faq-1",
      question: "Put simply, what does this service do for NDIS registration?",
      answer: "We are an independent consultant who assists individuals and businesses in becoming registered with the NDIS. Our role is to ensure that your business is able to pass the NDIS audit. We create custom and tailored documents based on your business, service offering, key personnel, and other factors that influence your registration. Once completed, we assist you to submit your application and can connect you with NDIS auditing partners to complete the required audit.",
      orderPosition: 0,
    },
    {
      id: "faq-2",
      question: "How long does the registration process take?",
      answer: "Depending on the service offerings you are looking at providing, the process can take as little as 3 months to complete. The timeline varies based on the complexity of your services and how quickly you can provide the necessary information.",
      orderPosition: 1,
    },
    {
      id: "faq-3",
      question: "Can't I work in the NDIS without being registered?",
      answer: "There are options for working in the NDIS in an unregistered capacity. However, these options carry very high risks. The NDIS 5 year plan states that they will be working to remove the option for businesses to work unregistered. Registration provides credibility, access to more clients, and ensures compliance with NDIS standards.",
      orderPosition: 2,
    },
    {
      id: "faq-4",
      question: "Is there a payment plan option?",
      answer: "Yes! We offer flexible payment plans including AfterPay to make NDIS registration more accessible for all businesses.",
      orderPosition: 3,
    },
    {
      id: "faq-5",
      question: "Am I eligible for NDIS registration?",
      answer: "The NDIS has eligibility criteria that are dependent on the types of services you are looking at providing. Generally, you need to demonstrate that you can deliver quality supports safely, have appropriate qualifications and experience, and meet NDIS Practice Standards. Contact us for a free eligibility assessment.",
      orderPosition: 4,
    },
    {
      id: "faq-6",
      question: "Will you help me with additional services?",
      answer: "Absolutely! Our focus is not just to get you registered but to then help you grow a profitable, compliant NDIS business. We offer ongoing support, training, and business development assistance.",
      orderPosition: 5,
    },
    {
      id: "faq-7",
      question: "What does the auditor charge?",
      answer: "The audit fee will depend on the services you are applying for. We have partnerships with NDIS approved auditors and can ensure they will provide you with competitive pricing. Audit fees typically range from $2,000 to $10,000 depending on your registration group.",
      orderPosition: 6,
    },
    {
      id: "faq-8",
      question: "Will you help me connect with NDIS participants?",
      answer: "Of course we will! Our team is dedicated to seeing your business succeed. We can provide guidance on marketing strategies, connecting with participants, and building your NDIS business.",
      orderPosition: 7,
    },
    {
      id: "faq-9",
      question: "Are there particular visa requirements for registration?",
      answer: "All that the NDIS requires is that you have working rights in Australia. As long as you can legally work in Australia, you can apply for NDIS registration.",
      orderPosition: 8,
    },
    {
      id: "faq-10",
      question: "What are the different types of registration?",
      answer: "The NDIS has over 36 registration groups, which can be loosely grouped into 3 modules: verification (low risk services), core (medium risk services), and specialist (high risk services). The type you need depends on the services you plan to provide.",
      orderPosition: 9,
    },
  ];

  for (const faq of faqs) {
    await prisma.fAQ.upsert({
      where: { id: faq.id },
      update: faq,
      create: faq,
    });
  }
  console.log("✅ FAQs created:", faqs.length);

  // Create site settings
  const settings = [
    { key: "companyName", value: "NDIS Template", category: "general" },
    { key: "contactEmail", value: "info@ndis-template.com", category: "general" },
    { key: "phoneNumber", value: "**** *** ***", category: "general" },
    { key: "address", value: "Australia Wide", category: "general" },
    { key: "primaryColor", value: "#6B46C1", category: "general" },
    { key: "secondaryColor", value: "#3B82F6", category: "general" },
    { key: "headerColor", value: "#660066", category: "general" },
    { key: "layoutMode", value: "fullwidth", category: "general" },
    { key: "stripePublishableKey", value: "", category: "payment" },
    { key: "stripeSecretKey", value: "", category: "payment" },
    { key: "bookingUrl", value: "", category: "general" },
    { key: "linkedinUrl", value: "https://linkedin.com", category: "social" },
    { key: "instagramUrl", value: "https://instagram.com", category: "social" },
    { key: "facebookUrl", value: "https://facebook.com", category: "social" },
    { key: "logoUrl", value: "/favicon.svg", category: "header" },
    {
      key: "acknowledgementText",
      value:
        "PRO CRM acknowledges the Traditional Custodians of the lands that we work on. We acknowledge the waterways, the land, the sky and all who inhabit these places. We acknowledge their ancestors, and Elders and recognise those who continue to protect and promote Aboriginal and Torres Strait Island cultures. We acknowledge the past and stand together for our future. PRO CRM celebrates diversity and all people.",
      category: "footer",
    },
    { key: "companyEmail", value: "support@procrm.com", category: "footer" },
  ];

  for (const setting of settings) {
    await prisma.siteSetting.upsert({
      where: { key: setting.key },
      update: { value: setting.value, category: setting.category },
      create: setting,
    });
  }
  console.log("✅ Site settings created:", settings.length);

  // Create content
  const content = [
    {
      section: "hero",
      key: "headline",
      value: "NDIS Registration Made Easy — Fast, Guaranteed & Affordable",
    },
    {
      section: "hero",
      key: "subheadline",
      value: "100% NDIS Success Rate | Lowest Price | Docs in 24 Hours",
    },
    {
      section: "statistics",
      key: "registrations",
      value: "3000",
    },
    {
      section: "statistics",
      key: "rating",
      value: "5",
    },
    {
      section: "statistics",
      key: "successRate",
      value: "100",
    },
    {
      section: "leadForm",
      key: "headline",
      value: "Get NDIS Registered!",
    },
    {
      section: "leadForm",
      key: "description",
      value: "Get instant access to audit-ready NDIS documentation trusted by 3,000+ providers",
    },
    {
      section: "whyChooseUs",
      key: "headline",
      value: "Why Choose Us?",
    },
    {
      section: "whyChooseUs",
      key: "description",
      value: "We're Australia's leading NDIS consulting group, delivering expert registration assistance that gets your provider registration approved fast and affordably.",
    },
  ];

  for (const item of content) {
    await prisma.content.upsert({
      where: {
        section_key: {
          section: item.section,
          key: item.key,
        },
      },
      update: { value: item.value },
      create: item,
    });
  }
  console.log("✅ Content created:", content.length);

  // Create NDIS Services
  const ndisServices = [
    {
      title: "Support Coordination",
      description: "Professional support coordination services in Melbourne to help you navigate and implement your NDIS plan effectively.",
      icon: "✓",
      orderPosition: 0,
    },
    {
      title: "Support Independent Living (SIL)",
      description: "Comprehensive support for independent living, helping you maintain your independence while receiving the assistance you need.",
      icon: "✓",
      orderPosition: 1,
    },
    {
      title: "Special Disability Accommodation (SDA)",
      description: "Specialized disability accommodation in Melbourne designed to meet your unique accessibility and support needs.",
      icon: "✓",
      orderPosition: 2,
    },
    {
      title: "Community Nursing Care",
      description: "Professional nursing care services delivered in your community to support your health and wellbeing.",
      icon: "✓",
      orderPosition: 3,
    },
    {
      title: "Community Support",
      description: "Engage in meaningful community participation activities with tailored support to build connections and skills.",
      icon: "✓",
      orderPosition: 4,
    },
    {
      title: "NDIS Core Supports",
      description: "Comprehensive disability support services covering daily activities, transport, consumables, and more.",
      icon: "✓",
      orderPosition: 5,
    },
    {
      title: "Disability and Mental Health Services",
      description: "Integrated support for disability and mental health needs, promoting overall wellbeing and independence.",
      icon: "✓",
      orderPosition: 6,
    },
    {
      title: "Personal Care",
      description: "Professional personal care assistance in Melbourne to support your daily living activities with dignity and respect.",
      icon: "✓",
      orderPosition: 7,
    },
    {
      title: "Respite Care",
      description: "Quality respite care services in Melbourne, providing temporary relief for carers and families.",
      icon: "✓",
      orderPosition: 8,
    },
    {
      title: "Domestic Care and Cleaning",
      description: "Professional domestic assistance and cleaning services in Melbourne to maintain a safe and comfortable home environment.",
      icon: "✓",
      orderPosition: 9,
    },
  ];

  for (const service of ndisServices) {
    await prisma.ndisService.upsert({
      where: {
        id: `service-${service.orderPosition}`,
      },
      update: service,
      create: {
        id: `service-${service.orderPosition}`,
        ...service,
      },
    });
  }
  console.log("✅ NDIS Services created:", ndisServices.length);

  console.log("🎉 Database seeded successfully!");
}

main()
  .catch((e) => {
    console.error("Error seeding database:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
