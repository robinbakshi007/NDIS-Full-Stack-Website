
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CheckCircle } from "lucide-react";
import Image from "next/image";

export const metadata = {
  title: "About Us - NDIS Registration Experts",
  description: "Learn about our mission to simplify NDIS registration and help providers succeed.",
};

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-purple-600 to-blue-600 text-white py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-5xl font-bold mb-6">About Us</h1>
            <p className="text-xl text-purple-100">
              Australia's trusted partner for NDIS provider registration
            </p>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold text-gray-900 mb-6">
                  Our Story
                </h2>
                <div className="space-y-4 text-gray-600 leading-relaxed">
                  <p>
                    We're Australia's leading NDIS consulting group, dedicated to
                    making NDIS provider registration accessible, affordable, and
                    stress-free for everyone.
                  </p>
                  <p>
                    With over 3,000 successful registrations and a 100% success
                    rate, we've helped countless providers navigate the complex
                    NDIS registration process and start making a difference in
                    their communities.
                  </p>
                  <p>
                    Our team of experts understands the challenges faced by NDIS
                    providers, and we're committed to providing personalized
                    support, audit-ready documentation, and ongoing guidance to
                    ensure your success.
                  </p>
                </div>
              </div>

              <div className="relative aspect-video rounded-2xl overflow-hidden shadow-2xl bg-gray-200">
                <Image
                  src="https://cdn.abacus.ai/images/cd1132f7-1b74-4ae9-949b-7376c75e7ef1.png"
                  alt="NDIS Support Team"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-20 bg-gradient-to-br from-purple-50 to-blue-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">
              Our Mission
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  title: "Simplify Registration",
                  description:
                    "Make the NDIS registration process straightforward and accessible for all providers.",
                },
                {
                  title: "Ensure Success",
                  description:
                    "Provide audit-ready documentation and expert guidance to guarantee approval.",
                },
                {
                  title: "Support Growth",
                  description:
                    "Help providers build sustainable, compliant NDIS businesses.",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className="bg-white rounded-2xl p-8 shadow-lg text-center"
                >
                  <CheckCircle className="h-12 w-12 text-purple-600 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-3">
                    {item.title}
                  </h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-20 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">
              Our Values
            </h2>
            <div className="space-y-6">
              {[
                {
                  title: "Transparency",
                  description:
                    "We believe in clear communication and honest pricing with no hidden fees.",
                },
                {
                  title: "Excellence",
                  description:
                    "We maintain the highest standards in documentation and service delivery.",
                },
                {
                  title: "Support",
                  description:
                    "We're with you every step of the way, from enquiry to approval and beyond.",
                },
                {
                  title: "Affordability",
                  description:
                    "We offer the best value for money without compromising on quality.",
                },
              ].map((value, index) => (
                <div
                  key={index}
                  className="flex items-start space-x-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-6"
                >
                  <CheckCircle className="h-6 w-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {value.title}
                    </h3>
                    <p className="text-gray-600">{value.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
