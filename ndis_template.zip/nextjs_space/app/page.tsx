'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { HeroCarousel } from "@/components/hero-carousel";
import { StatisticsBar } from "@/components/statistics-bar";
import { ServicesSection } from "@/components/services-section";
import { BenefitsCarousel } from "@/components/benefits-carousel";
import { TestimonialsCarousel } from "@/components/testimonials-carousel";
import { WhyChooseUs } from "@/components/why-choose-us";
import { ProcessSteps } from "@/components/process-steps";
import { FAQAccordion } from "@/components/faq-accordion";
import { LeadFormBottom } from "@/components/lead-form-bottom";
import { NewsletterPopup } from "@/components/newsletter-popup";

export default function HomePage() {
  const [layoutMode, setLayoutMode] = useState<string>('fullwidth');

  useEffect(() => {
    // Fetch layout settings
    const fetchSettings = async () => {
      try {
        const response = await fetch('/api/settings');
        if (response.ok) {
          const data = await response.json();
          setLayoutMode(data?.layoutMode || 'fullwidth');
        }
      } catch (error) {
        console.error('Failed to fetch settings:', error);
      }
    };

    fetchSettings();
  }, []);

  const containerClass = layoutMode === 'boxed' 
    ? 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8' 
    : '';

  return (
    <div className="min-h-screen">
      <Header />
      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className={containerClass}>
          <HeroCarousel />
        </div>
        <div className={containerClass}>
          <StatisticsBar />
        </div>
        <div className={containerClass}>
          <ServicesSection />
        </div>
        <div className={containerClass}>
          <BenefitsCarousel />
        </div>
        <div className={containerClass}>
          <TestimonialsCarousel />
        </div>
        <div className={containerClass}>
          <WhyChooseUs />
        </div>
        <div className={containerClass}>
          <ProcessSteps />
        </div>
        <div className={containerClass}>
          <FAQAccordion />
        </div>
        {/* Lead Form at Bottom - 2 Column Layout */}
        <div className={containerClass}>
          <LeadFormBottom />
        </div>
      </motion.main>
      <Footer />
      
      {/* Newsletter Popup - Shows after 10 seconds */}
      <NewsletterPopup />
    </div>
  );
}
