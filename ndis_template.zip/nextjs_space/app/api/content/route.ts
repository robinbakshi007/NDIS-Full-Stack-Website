
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { isAdmin } from "@/lib/auth";

export async function GET() {
  try {
    const content = await prisma.content.findMany();

    // Group by section
    const contentObj: Record<string, Record<string, string>> = {};
    content.forEach((item: any) => {
      if (!contentObj[item.section]) {
        contentObj[item.section] = {};
      }
      contentObj[item.section][item.key] = item.value;
    });

    return NextResponse.json(contentObj);
  } catch (error: any) {
    console.error("Error fetching content:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: Request) {
  try {
    const admin = await isAdmin();
    if (!admin) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { section, key, value } = body;

    if (!section || !key) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    const content = await prisma.content.upsert({
      where: {
        section_key: {
          section,
          key
        }
      },
      update: { value },
      create: { section, key, value }
    });

    return NextResponse.json(content);
  } catch (error: any) {
    console.error("Error updating content:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
