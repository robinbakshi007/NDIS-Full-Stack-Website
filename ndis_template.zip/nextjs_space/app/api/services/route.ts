
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";

// GET all services
export async function GET() {
  try {
    const services = await prisma.ndisService.findMany({
      where: { visible: true },
      orderBy: { orderPosition: "asc" },
    });

    return NextResponse.json({ services });
  } catch (error) {
    console.error("Error fetching services:", error);
    return NextResponse.json(
      { error: "Failed to fetch services" },
      { status: 500 }
    );
  }
}

// POST new service (admin only)
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || session.user?.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { title, description, icon } = body;

    if (!title || !description) {
      return NextResponse.json(
        { error: "Title and description are required" },
        { status: 400 }
      );
    }

    // Get the highest order position
    const maxOrder = await prisma.ndisService.findFirst({
      orderBy: { orderPosition: "desc" },
      select: { orderPosition: true },
    });

    const service = await prisma.ndisService.create({
      data: {
        title,
        description,
        icon: icon || "✓",
        orderPosition: (maxOrder?.orderPosition || 0) + 1,
      },
    });

    return NextResponse.json({ service }, { status: 201 });
  } catch (error) {
    console.error("Error creating service:", error);
    return NextResponse.json(
      { error: "Failed to create service" },
      { status: 500 }
    );
  }
}
