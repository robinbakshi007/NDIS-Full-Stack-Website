
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth-options";
import { prisma } from "@/lib/db";

// POST reorder services (admin only)
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || session.user?.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { serviceIds } = body; // Array of service IDs in new order

    if (!Array.isArray(serviceIds)) {
      return NextResponse.json(
        { error: "Invalid serviceIds array" },
        { status: 400 }
      );
    }

    // Update order position for each service
    await Promise.all(
      serviceIds.map((id: string, index: number) =>
        prisma.ndisService.update({
          where: { id },
          data: { orderPosition: index },
        })
      )
    );

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error reordering services:", error);
    return NextResponse.json(
      { error: "Failed to reorder services" },
      { status: 500 }
    );
  }
}
