
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { isAdmin } from "@/lib/auth";

export async function GET() {
  try {
    const packages = await prisma.pricingPackage.findMany({
      where: { visible: true },
      orderBy: { orderPosition: "asc" }
    });

    return NextResponse.json(packages);
  } catch (error: any) {
    console.error("Error fetching pricing:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
