
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { isAdmin } from "@/lib/auth";

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const admin = await isAdmin();
    if (!admin) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { name, currentPrice, originalPrice, description, features, visible } = body;

    const pricingPackage = await prisma.pricingPackage.update({
      where: { id: params.id },
      data: {
        ...(name && { name }),
        ...(currentPrice !== undefined && { currentPrice: parseInt(currentPrice) }),
        ...(originalPrice !== undefined && { originalPrice: parseInt(originalPrice) }),
        ...(description !== undefined && { description }),
        ...(features && { features }),
        ...(visible !== undefined && { visible })
      }
    });

    return NextResponse.json(pricingPackage);
  } catch (error: any) {
    console.error("Error updating pricing:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
