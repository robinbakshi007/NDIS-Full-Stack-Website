import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';
import { createStripeCustomer, createCheckoutSession, STRIPE_PLANS } from '@/lib/stripe';

// GET /api/super-admin/tenants - List all tenants
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user?.role !== 'superadmin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const tenants = await prisma.tenant.findMany({
      include: {
        _count: {
          select: {
            users: true,
            leads: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(tenants);
  } catch (error: any) {
    console.error('Error fetching tenants:', error);
    return NextResponse.json(
      { error: 'Failed to fetch tenants' },
      { status: 500 }
    );
  }
}

// POST /api/super-admin/tenants - Create new tenant
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user?.role !== 'superadmin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { businessName, subdomain, contactName, contactEmail, contactPhone, subscriptionPlan } = body;

    // Validate required fields
    if (!businessName || !subdomain || !contactName || !contactEmail || !subscriptionPlan) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Check if subdomain already exists
    const existingTenant = await prisma.tenant.findUnique({
      where: { subdomain },
    });

    if (existingTenant) {
      return NextResponse.json(
        { error: 'Subdomain already exists' },
        { status: 400 }
      );
    }

    // Create Stripe customer
    const stripeCustomer = await createStripeCustomer({
      email: contactEmail,
      name: businessName,
      metadata: {
        subdomain,
        contactName,
      },
    });

    // Create tenant in database
    const tenant = await prisma.tenant.create({
      data: {
        businessName,
        subdomain,
        contactName,
        contactEmail,
        contactPhone,
        subscriptionPlan,
        stripeCustomerId: stripeCustomer.id,
        status: 'active',
      },
    });

    // Get the price ID for the selected plan
    const plan = STRIPE_PLANS[subscriptionPlan as keyof typeof STRIPE_PLANS];
    if (!plan) {
      return NextResponse.json(
        { error: 'Invalid subscription plan' },
        { status: 400 }
      );
    }

    // Create Stripe Checkout Session
    const origin = request.headers.get('origin') || 'http://localhost:3000';
    const checkoutSession = await createCheckoutSession({
      customerId: stripeCustomer.id,
      priceId: plan.priceId,
      successUrl: `${origin}/super-admin/tenants?success=true&tenant_id=${tenant.id}`,
      cancelUrl: `${origin}/super-admin/tenants?canceled=true`,
      metadata: {
        tenantId: tenant.id,
        subdomain,
      },
    });

    return NextResponse.json({
      tenant,
      checkoutUrl: checkoutSession.url,
    }, { status: 201 });
  } catch (error: any) {
    console.error('Error creating tenant:', error);
    return NextResponse.json(
      { error: 'Failed to create tenant', details: error.message },
      { status: 500 }
    );
  }
}
