
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { isAdmin } from "@/lib/auth";

export async function PATCH(request: Request) {
  try {
    const admin = await isAdmin();
    if (!admin) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { testimonials } = body;

    if (!Array.isArray(testimonials)) {
      return NextResponse.json(
        { error: "Invalid data format" },
        { status: 400 }
      );
    }

    // Update order positions
    await Promise.all(
      testimonials.map((item: any, index: number) =>
        prisma.testimonial.update({
          where: { id: item.id },
          data: { orderPosition: index }
        })
      )
    );

    return NextResponse.json({ message: "Order updated successfully" });
  } catch (error: any) {
    console.error("Error reordering testimonials:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
