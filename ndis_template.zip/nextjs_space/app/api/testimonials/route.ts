
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { isAdmin } from "@/lib/auth";

export async function GET() {
  try {
    const testimonials = await prisma.testimonial.findMany({
      where: { visible: true },
      orderBy: { orderPosition: "asc" }
    });

    return NextResponse.json(testimonials);
  } catch (error: any) {
    console.error("Error fetching testimonials:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const admin = await isAdmin();
    if (!admin) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { name, company, quote, photoUrl } = body;

    if (!name || !quote) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    // Get the highest order position
    const maxOrder = await prisma.testimonial.findFirst({
      orderBy: { orderPosition: "desc" },
      select: { orderPosition: true }
    });

    const testimonial = await prisma.testimonial.create({
      data: {
        name,
        company: company ?? "",
        quote,
        photoUrl: photoUrl ?? "",
        orderPosition: (maxOrder?.orderPosition ?? 0) + 1
      }
    });

    return NextResponse.json(testimonial, { status: 201 });
  } catch (error: any) {
    console.error("Error creating testimonial:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
