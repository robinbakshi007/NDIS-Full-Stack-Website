
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { isAdmin } from "@/lib/auth";

export async function GET() {
  try {
    const faqs = await prisma.fAQ.findMany({
      where: { visible: true },
      orderBy: { orderPosition: "asc" }
    });

    return NextResponse.json(faqs);
  } catch (error: any) {
    console.error("Error fetching FAQs:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const admin = await isAdmin();
    if (!admin) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { question, answer, category } = body;

    if (!question || !answer) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    // Get the highest order position
    const maxOrder = await prisma.fAQ.findFirst({
      orderBy: { orderPosition: "desc" },
      select: { orderPosition: true }
    });

    const faq = await prisma.fAQ.create({
      data: {
        question,
        answer,
        category: category ?? null,
        orderPosition: (maxOrder?.orderPosition ?? 0) + 1
      }
    });

    return NextResponse.json(faq, { status: 201 });
  } catch (error: any) {
    console.error("Error creating FAQ:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
