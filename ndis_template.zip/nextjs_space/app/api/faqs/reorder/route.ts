
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { isAdmin } from "@/lib/auth";

export async function PATCH(request: Request) {
  try {
    const admin = await isAdmin();
    if (!admin) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { faqs } = body;

    if (!Array.isArray(faqs)) {
      return NextResponse.json(
        { error: "Invalid data format" },
        { status: 400 }
      );
    }

    // Update order positions
    await Promise.all(
      faqs.map((item: any, index: number) =>
        prisma.fAQ.update({
          where: { id: item.id },
          data: { orderPosition: index }
        })
      )
    );

    return NextResponse.json({ message: "Order updated successfully" });
  } catch (error: any) {
    console.error("Error reordering FAQs:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
