
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { PricingCards } from "@/components/pricing-cards";

export default function PricingPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary to-primary/80 text-white py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                NDIS Registration Packages
              </h1>
              <p className="text-xl md:text-2xl text-white/90 max-w-3xl mx-auto">
                Affordable, transparent pricing for NDIS registration. Choose the package that best fits your needs.
              </p>
            </div>
          </div>
        </section>

        {/* Pricing Cards */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <PricingCards />
          </div>
        </section>

        {/* Features Section */}
        <section className="bg-gray-50 py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                What's Included in All Packages
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Every package includes comprehensive support to ensure your successful NDIS registration.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  title: "Expert Guidance",
                  description: "Step-by-step support from experienced NDIS consultants throughout your registration journey."
                },
                {
                  title: "Audit-Ready Documentation",
                  description: "Professionally prepared documentation that meets all NDIS Commission requirements."
                },
                {
                  title: "Fast Turnaround",
                  description: "Receive your complete documentation package within 24 hours of providing required information."
                },
                {
                  title: "Ongoing Support",
                  description: "Post-registration support to help you maintain compliance and grow your business."
                },
                {
                  title: "Training Included",
                  description: "Comprehensive training on using your documentation and maintaining compliance."
                },
                {
                  title: "100% Success Rate",
                  description: "Our proven process ensures successful registration with the NDIS Commission."
                }
              ].map((feature) => (
                <div key={feature.title} className="bg-white rounded-lg p-6 shadow-md">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
