
"use client";

export const dynamic = "force-dynamic";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export default function AdminContentPage() {
  const [content, setContent] = useState<Record<string, Record<string, string>>>({});
  const [loading, setLoading] = useState(true);

  const fetchContent = async () => {
    try {
      const response = await fetch("/api/content");
      if (!response.ok) throw new Error("Failed to fetch");

      const data = await response.json();
      setContent(data ?? {});
    } catch (error) {
      toast.error("Failed to load content");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContent();
  }, []);

  const handleUpdate = async (section: string, key: string, value: string) => {
    try {
      const response = await fetch("/api/content", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ section, key, value }),
      });

      if (!response.ok) throw new Error("Failed to update");

      toast.success("Content updated successfully");
    } catch (error) {
      toast.error("Failed to update content");
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <p className="text-center text-gray-600">Loading...</p>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Content Management</h1>
        <p className="text-gray-600 mt-2">
          Update website content and messaging
        </p>
      </div>

      <div className="space-y-6">
        {/* Hero Section */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Hero Section
          </h2>
          <div className="space-y-4">
            <div>
              <Label>Main Headline</Label>
              <Input
                defaultValue={content?.hero?.headline ?? "NDIS Registration Made Easy — Fast, Guaranteed & Affordable"}
                onBlur={(e) => handleUpdate("hero", "headline", e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Subheadline</Label>
              <Textarea
                defaultValue={content?.hero?.subheadline ?? "100% NDIS Success Rate | Lowest Price | Docs in 24 Hours"}
                onBlur={(e) => handleUpdate("hero", "subheadline", e.target.value)}
                className="mt-1"
                rows={2}
              />
            </div>
          </div>
        </div>

        {/* Statistics Section */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Statistics
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Registrations Count</Label>
              <Input
                type="number"
                defaultValue={content?.statistics?.registrations ?? "3000"}
                onBlur={(e) => handleUpdate("statistics", "registrations", e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Star Rating</Label>
              <Input
                type="number"
                defaultValue={content?.statistics?.rating ?? "5"}
                onBlur={(e) => handleUpdate("statistics", "rating", e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Success Rate (%)</Label>
              <Input
                type="number"
                defaultValue={content?.statistics?.successRate ?? "100"}
                onBlur={(e) => handleUpdate("statistics", "successRate", e.target.value)}
                className="mt-1"
              />
            </div>
          </div>
        </div>

        {/* Lead Form Section */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Lead Form
          </h2>
          <div className="space-y-4">
            <div>
              <Label>Form Headline</Label>
              <Input
                defaultValue={content?.leadForm?.headline ?? "Get NDIS Registered!"}
                onBlur={(e) => handleUpdate("leadForm", "headline", e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Form Description</Label>
              <Textarea
                defaultValue={
                  content?.leadForm?.description ??
                  "Get instant access to audit-ready NDIS documentation trusted by 3,000+ providers"
                }
                onBlur={(e) => handleUpdate("leadForm", "description", e.target.value)}
                className="mt-1"
                rows={3}
              />
            </div>
          </div>
        </div>

        {/* Why Choose Us Section */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Why Choose Us
          </h2>
          <div className="space-y-4">
            <div>
              <Label>Section Headline</Label>
              <Input
                defaultValue={content?.whyChooseUs?.headline ?? "Why Choose Us?"}
                onBlur={(e) => handleUpdate("whyChooseUs", "headline", e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Section Description</Label>
              <Textarea
                defaultValue={
                  content?.whyChooseUs?.description ??
                  "We're Australia's leading NDIS consulting group, delivering expert registration assistance that gets your provider registration approved fast and affordably."
                }
                onBlur={(e) => handleUpdate("whyChooseUs", "description", e.target.value)}
                className="mt-1"
                rows={3}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-800">
          <strong>Note:</strong> Changes are saved automatically when you finish
          editing each field. Refresh the homepage to see your updates.
        </p>
      </div>
    </div>
  );
}
