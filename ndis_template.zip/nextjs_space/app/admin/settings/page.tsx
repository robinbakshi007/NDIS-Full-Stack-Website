
"use client";

export const dynamic = "force-dynamic";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Save } from "lucide-react";

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const fetchSettings = async () => {
    try {
      const response = await fetch("/api/settings");
      if (!response.ok) throw new Error("Failed to fetch");

      const data = await response.json();
      setSettings(data ?? {});
    } catch (error) {
      toast.error("Failed to load settings");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleSave = async () => {
    setSaving(true);

    try {
      const response = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });

      if (!response.ok) throw new Error("Failed to save");

      toast.success("Settings saved successfully");
    } catch (error) {
      toast.error("Failed to save settings");
    } finally {
      setSaving(false);
    }
  };

  const updateSetting = (key: string, value: string) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  if (loading) {
    return (
      <div className="p-8">
        <p className="text-center text-gray-600">Loading...</p>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Site Settings</h1>
        <p className="text-gray-600 mt-2">
          Configure your website settings and integrations
        </p>
      </div>

      <div className="space-y-6">
        {/* General Settings */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            General Information
          </h2>
          <div className="space-y-4">
            <div>
              <Label>Company Name</Label>
              <Input
                value={settings?.companyName ?? "NDIS Template"}
                onChange={(e) => updateSetting("companyName", e.target.value)}
                className="mt-1"
                placeholder="Your Company Name"
              />
            </div>

            <div>
              <Label>Contact Email</Label>
              <Input
                type="email"
                value={settings?.contactEmail ?? "info@ndis-template.com"}
                onChange={(e) => updateSetting("contactEmail", e.target.value)}
                className="mt-1"
                placeholder="contact@example.com"
              />
            </div>

            <div>
              <Label>Phone Number</Label>
              <Input
                type="tel"
                value={settings?.phoneNumber ?? "1300 XXX XXX"}
                onChange={(e) => updateSetting("phoneNumber", e.target.value)}
                className="mt-1"
                placeholder="1300 XXX XXX"
              />
            </div>

            <div>
              <Label>Business Address</Label>
              <Input
                value={settings?.address ?? "Australia Wide"}
                onChange={(e) => updateSetting("address", e.target.value)}
                className="mt-1"
                placeholder="Your business address"
              />
            </div>
          </div>
        </div>

        {/* Header Logo Upload */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Header Logo
          </h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="logo-upload">Upload Logo</Label>
              <Input
                id="logo-upload"
                type="file"
                accept="image/*"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;

                  const formData = new FormData();
                  formData.append("file", file);

                  try {
                    const response = await fetch("/api/upload", {
                      method: "POST",
                      body: formData,
                    });
                    
                    if (!response.ok) throw new Error("Upload failed");
                    
                    const data = await response.json();
                    updateSetting("logoUrl", data.url);
                    toast.success("Logo uploaded successfully");
                  } catch (error) {
                    toast.error("Failed to upload logo");
                  }
                }}
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-2">
                Upload your company logo (PNG/SVG recommended, max 5MB)
              </p>
            </div>

            {settings?.logoUrl && (
              <div className="mt-4">
                <Label>Current Logo Preview</Label>
                <div className="relative h-16 w-48 bg-gray-100 rounded border mt-2">
                  <img
                    src={settings.logoUrl}
                    alt="Logo Preview"
                    className="object-contain h-full w-full p-2"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Brand Colors */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Brand Colors
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Header Color</Label>
              <div className="flex items-center space-x-2 mt-1">
                <Input
                  type="color"
                  value={settings?.headerColor ?? "#660066"}
                  onChange={(e) => updateSetting("headerColor", e.target.value)}
                  className="w-20 h-10"
                />
                <Input
                  value={settings?.headerColor ?? "#660066"}
                  onChange={(e) => updateSetting("headerColor", e.target.value)}
                  placeholder="#660066"
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Header background color
              </p>
            </div>

            <div>
              <Label>Primary Color</Label>
              <div className="flex items-center space-x-2 mt-1">
                <Input
                  type="color"
                  value={settings?.primaryColor ?? "#6B46C1"}
                  onChange={(e) => updateSetting("primaryColor", e.target.value)}
                  className="w-20 h-10"
                />
                <Input
                  value={settings?.primaryColor ?? "#6B46C1"}
                  onChange={(e) => updateSetting("primaryColor", e.target.value)}
                  placeholder="#6B46C1"
                />
              </div>
            </div>

            <div>
              <Label>Secondary Color</Label>
              <div className="flex items-center space-x-2 mt-1">
                <Input
                  type="color"
                  value={settings?.secondaryColor ?? "#3B82F6"}
                  onChange={(e) => updateSetting("secondaryColor", e.target.value)}
                  className="w-20 h-10"
                />
                <Input
                  value={settings?.secondaryColor ?? "#3B82F6"}
                  onChange={(e) => updateSetting("secondaryColor", e.target.value)}
                  placeholder="#3B82F6"
                />
              </div>
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-4">
            Note: Header color changes take effect immediately. Other colors may require CSS customization.
          </p>
        </div>

        {/* Layout Settings */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Layout Settings
          </h2>
          <div>
            <Label>Layout Mode</Label>
            <select
              value={settings?.layoutMode ?? "fullwidth"}
              onChange={(e) => updateSetting("layoutMode", e.target.value)}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              <option value="fullwidth">Full Width</option>
              <option value="boxed">Boxed (Centered Container)</option>
            </select>
            <p className="text-xs text-gray-500 mt-2">
              Choose between full-width layout or centered boxed layout with max width
            </p>
          </div>
        </div>

        {/* Stripe Integration */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Stripe Integration
          </h2>
          <div className="space-y-4">
            <div>
              <Label>Stripe Publishable Key</Label>
              <Input
                value={settings?.stripePublishableKey ?? ""}
                onChange={(e) =>
                  updateSetting("stripePublishableKey", e.target.value)
                }
                className="mt-1"
                placeholder="pk_test_..."
              />
            </div>

            <div>
              <Label>Stripe Secret Key</Label>
              <Input
                type="password"
                value={settings?.stripeSecretKey ?? ""}
                onChange={(e) =>
                  updateSetting("stripeSecretKey", e.target.value)
                }
                className="mt-1"
                placeholder="sk_test_..."
              />
            </div>
          </div>
        </div>

        {/* Calendar Booking */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Calendar Booking
          </h2>
          <div>
            <Label>Booking Link (Calendly / Google Calendar)</Label>
            <Input
              value={settings?.bookingUrl ?? ""}
              onChange={(e) => updateSetting("bookingUrl", e.target.value)}
              className="mt-1"
              placeholder="https://calendly.com/your-link"
            />
            <p className="text-xs text-gray-500 mt-2">
              Paste your Calendly or Google Calendar booking URL
            </p>
          </div>
        </div>

        {/* Social Media */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Social Media Links
          </h2>
          <div className="space-y-4">
            <div>
              <Label>LinkedIn URL</Label>
              <Input
                value={settings?.linkedinUrl ?? ""}
                onChange={(e) => updateSetting("linkedinUrl", e.target.value)}
                className="mt-1"
                placeholder="https://linkedin.com/company/..."
              />
            </div>

            <div>
              <Label>Instagram URL</Label>
              <Input
                value={settings?.instagramUrl ?? ""}
                onChange={(e) => updateSetting("instagramUrl", e.target.value)}
                className="mt-1"
                placeholder="https://instagram.com/..."
              />
            </div>

            <div>
              <Label>Facebook URL</Label>
              <Input
                value={settings?.facebookUrl ?? ""}
                onChange={(e) => updateSetting("facebookUrl", e.target.value)}
                className="mt-1"
                placeholder="https://facebook.com/..."
              />
            </div>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="mt-8 flex justify-end">
        <Button
          onClick={handleSave}
          disabled={saving}
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8"
        >
          {saving ? (
            "Saving..."
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Save All Settings
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
