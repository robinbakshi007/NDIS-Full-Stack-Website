
"use client";

export const dynamic = "force-dynamic";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

interface PricingPackage {
  id: string;
  name: string;
  currentPrice: number;
  originalPrice: number;
  description: string;
  features: string[];
}

export default function AdminPricingPage() {
  const [packages, setPackages] = useState<PricingPackage[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchPackages = async () => {
    try {
      const response = await fetch("/api/pricing");
      if (!response.ok) throw new Error("Failed to fetch");

      const data = await response.json();
      setPackages(data ?? []);
    } catch (error) {
      toast.error("Failed to load pricing packages");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPackages();
  }, []);

  const handleUpdate = async (packageId: string, field: string, value: string | number) => {
    try {
      const response = await fetch(`/api/pricing/${packageId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [field]: value }),
      });

      if (!response.ok) throw new Error("Failed to update");

      toast.success("Package updated successfully");
      fetchPackages();
    } catch (error) {
      toast.error("Failed to update package");
    }
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Pricing Management</h1>
        <p className="text-gray-600 mt-2">
          Update pricing packages and features
        </p>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <p className="text-gray-600">Loading...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {packages.map((pkg) => (
            <div key={pkg.id} className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">
                {pkg.name}
              </h2>

              <div className="space-y-4">
                <div>
                  <Label>Current Price ($)</Label>
                  <Input
                    type="number"
                    defaultValue={pkg.currentPrice}
                    onBlur={(e) =>
                      handleUpdate(pkg.id, "currentPrice", e.target.value)
                    }
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label>Original Price ($)</Label>
                  <Input
                    type="number"
                    defaultValue={pkg.originalPrice}
                    onBlur={(e) =>
                      handleUpdate(pkg.id, "originalPrice", e.target.value)
                    }
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label>Description</Label>
                  <Input
                    defaultValue={pkg.description ?? ""}
                    onBlur={(e) =>
                      handleUpdate(pkg.id, "description", e.target.value)
                    }
                    className="mt-1"
                    placeholder="Package description"
                  />
                </div>

                <div className="pt-4 border-t">
                  <h3 className="font-semibold text-gray-900 mb-2">Features</h3>
                  <ul className="space-y-1 text-sm text-gray-600">
                    {Array.isArray(pkg.features) &&
                      pkg.features.map((feature, index) => (
                        <li key={index}>• {feature}</li>
                      ))}
                  </ul>
                  <p className="text-xs text-gray-500 mt-2">
                    Features are managed via database
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
