
"use client";

export const dynamic = "force-dynamic";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Edit2, ChevronUp, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import Image from "next/image";

interface Testimonial {
  id: string;
  name: string;
  company: string;
  quote: string;
  photoUrl: string;
  orderPosition: number;
}

export default function AdminTestimonialsPage() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    quote: "",
    photoUrl: "",
  });

  const fetchTestimonials = async () => {
    try {
      const response = await fetch("/api/testimonials");
      if (!response.ok) throw new Error("Failed to fetch");

      const data = await response.json();
      setTestimonials(data ?? []);
    } catch (error) {
      toast.error("Failed to load testimonials");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTestimonials();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const url = editingId
        ? `/api/testimonials/${editingId}`
        : "/api/testimonials";
      const method = editingId ? "PATCH" : "POST";

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) throw new Error("Failed to save");

      toast.success(
        editingId ? "Testimonial updated" : "Testimonial added"
      );
      setFormData({ name: "", company: "", quote: "", photoUrl: "" });
      setEditingId(null);
      fetchTestimonials();
    } catch (error) {
      toast.error("Failed to save testimonial");
    }
  };

  const handleEdit = (testimonial: Testimonial) => {
    setEditingId(testimonial.id);
    setFormData({
      name: testimonial.name,
      company: testimonial.company ?? "",
      quote: testimonial.quote,
      photoUrl: testimonial.photoUrl ?? "",
    });
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this testimonial?")) return;

    try {
      const response = await fetch(`/api/testimonials/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) throw new Error("Failed to delete");

      toast.success("Testimonial deleted");
      fetchTestimonials();
    } catch (error) {
      toast.error("Failed to delete testimonial");
    }
  };

  const moveTestimonial = async (index: number, direction: "up" | "down") => {
    const newTestimonials = [...testimonials];
    const targetIndex = direction === "up" ? index - 1 : index + 1;

    if (targetIndex < 0 || targetIndex >= newTestimonials.length) return;

    [newTestimonials[index], newTestimonials[targetIndex]] = [
      newTestimonials[targetIndex]!,
      newTestimonials[index]!,
    ];

    try {
      const response = await fetch("/api/testimonials/reorder", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ testimonials: newTestimonials }),
      });

      if (!response.ok) throw new Error("Failed to reorder");

      setTestimonials(newTestimonials);
      toast.success("Order updated");
    } catch (error) {
      toast.error("Failed to reorder testimonials");
    }
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">
          Testimonials Management
        </h1>
        <p className="text-gray-600 mt-2">
          Add, edit, and reorder client testimonials
        </p>
      </div>

      {/* Add/Edit Form */}
      <div className="bg-white rounded-xl shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          {editingId ? "Edit Testimonial" : "Add New Testimonial"}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                required
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                placeholder="John Doe"
              />
            </div>

            <div>
              <Label htmlFor="company">Company</Label>
              <Input
                id="company"
                value={formData.company}
                onChange={(e) =>
                  setFormData({ ...formData, company: e.target.value })
                }
                placeholder="Company Name"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="quote">Quote *</Label>
            <Textarea
              id="quote"
              required
              value={formData.quote}
              onChange={(e) =>
                setFormData({ ...formData, quote: e.target.value })
              }
              placeholder="What did the client say?"
              rows={4}
            />
          </div>

          <div>
            <Label htmlFor="photoUrl">Photo URL</Label>
            <Input
              id="photoUrl"
              value={formData.photoUrl}
              onChange={(e) =>
                setFormData({ ...formData, photoUrl: e.target.value })
              }
              placeholder="https://i.ytimg.com/vi/0dV99J3Ow54/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLCEMcqWr8Q87u8TfMRZtyOk9zsnmA"
            />
          </div>

          <div className="flex gap-4">
            <Button
              type="submit"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
            >
              {editingId ? "Update" : "Add"} Testimonial
            </Button>
            {editingId && (
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setEditingId(null);
                  setFormData({ name: "", company: "", quote: "", photoUrl: "" });
                }}
              >
                Cancel
              </Button>
            )}
          </div>
        </form>
      </div>

      {/* Testimonials List */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Current Testimonials
        </h2>

        {loading ? (
          <p className="text-gray-600 text-center py-8">Loading...</p>
        ) : testimonials.length === 0 ? (
          <p className="text-gray-600 text-center py-8">No testimonials yet</p>
        ) : (
          <div className="space-y-4">
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.id}
                className="border rounded-lg p-4 hover:border-purple-300 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4 flex-1">
                    {testimonial.photoUrl && (
                      <div className="relative w-16 h-16 rounded-full overflow-hidden flex-shrink-0 bg-gray-200">
                        <Image
                          src={testimonial.photoUrl}
                          alt={testimonial.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                    )}
                    <div className="flex-1">
                      <div className="font-semibold text-gray-900">
                        {testimonial.name}
                      </div>
                      {testimonial.company && (
                        <div className="text-sm text-gray-600">
                          {testimonial.company}
                        </div>
                      )}
                      <p className="text-gray-700 mt-2 italic">
                        "{testimonial.quote}"
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 ml-4">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => moveTestimonial(index, "up")}
                      disabled={index === 0}
                    >
                      <ChevronUp className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => moveTestimonial(index, "down")}
                      disabled={index === testimonials.length - 1}
                    >
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(testimonial)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(testimonial.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
