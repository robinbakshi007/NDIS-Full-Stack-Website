
"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Upload, Save } from "lucide-react";
import Image from "next/image";

export default function FooterSettingsPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [settings, setSettings] = useState({
    logoUrl: "/favicon.svg",
    acknowledgementText: "",
    facebookUrl: "",
    linkedinUrl: "",
    instagramUrl: "",
    companyEmail: "",
    phoneNumber: "",
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await fetch("/api/settings?category=footer");
      const data = await response.json();

      if (data.settings) {
        const footerSettings: any = {};
        data.settings.forEach((setting: any) => {
          footerSettings[setting.key] = setting.value;
        });

        // Also fetch phone number from general settings
        const generalResponse = await fetch("/api/settings?category=general");
        const generalData = await generalResponse.json();
        if (generalData.settings) {
          generalData.settings.forEach((setting: any) => {
            if (setting.key === "phoneNumber") {
              footerSettings.phoneNumber = setting.value;
            }
          });
        }

        // Fetch social links
        const socialResponse = await fetch("/api/settings?category=social");
        const socialData = await socialResponse.json();
        if (socialData.settings) {
          socialData.settings.forEach((setting: any) => {
            if (setting.key === "facebookUrl") {
              footerSettings.facebookUrl = setting.value;
            }
            if (setting.key === "linkedinUrl") {
              footerSettings.linkedinUrl = setting.value;
            }
            if (setting.key === "instagramUrl") {
              footerSettings.instagramUrl = setting.value;
            }
          });
        }

        setSettings((prev) => ({ ...prev, ...footerSettings }));
      }
    } catch (error) {
      toast.error("Failed to load footer settings");
    } finally {
      setLoading(false);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast.error("Please upload an image file");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image must be less than 5MB");
      return;
    }

    setUploading(true);

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      const data = await response.json();
      setSettings((prev) => ({ ...prev, logoUrl: data.url }));
      toast.success("Logo uploaded successfully");
    } catch (error) {
      toast.error("Failed to upload logo");
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);

    try {
      // Save footer settings
      const footerSettings = [
        { key: "logoUrl", value: settings.logoUrl, category: "footer" },
        { key: "acknowledgementText", value: settings.acknowledgementText, category: "footer" },
        { key: "companyEmail", value: settings.companyEmail, category: "footer" },
      ];

      for (const setting of footerSettings) {
        await fetch("/api/settings", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(setting),
        });
      }

      // Save phone number to general settings
      await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          key: "phoneNumber",
          value: settings.phoneNumber,
          category: "general",
        }),
      });

      // Save social links
      const socialSettings = [
        { key: "facebookUrl", value: settings.facebookUrl, category: "social" },
        { key: "linkedinUrl", value: settings.linkedinUrl, category: "social" },
        { key: "instagramUrl", value: settings.instagramUrl, category: "social" },
      ];

      for (const setting of socialSettings) {
        await fetch("/api/settings", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(setting),
        });
      }

      toast.success("Footer settings saved successfully");
    } catch (error) {
      toast.error("Failed to save footer settings");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <h1 className="text-3xl font-bold mb-8">Footer Settings</h1>
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="max-w-4xl">
        <h1 className="text-3xl font-bold mb-8">Footer Settings</h1>

        <div className="space-y-6">
          {/* Logo Upload */}
          <Card>
            <CardHeader>
              <CardTitle>Company Logo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-6">
                <div className="relative h-24 w-48 border rounded-lg overflow-hidden bg-gray-50">
                  <Image
                    src={settings.logoUrl}
                    alt="Company Logo"
                    fill
                    className="object-contain"
                  />
                </div>
                <div className="flex-1">
                  <Label htmlFor="logo-upload" className="cursor-pointer">
                    <div className="flex items-center gap-2 bg-primary text-white px-4 py-2 rounded hover:bg-primary/90 transition-colors w-fit">
                      <Upload className="h-4 w-4" />
                      {uploading ? "Uploading..." : "Upload Logo"}
                    </div>
                  </Label>
                  <input
                    id="logo-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                    disabled={uploading}
                  />
                  <p className="text-sm text-gray-500 mt-2">
                    Recommended: PNG or SVG, max 5MB
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="phoneNumber">Phone Number</Label>
                <Input
                  id="phoneNumber"
                  value={settings.phoneNumber}
                  onChange={(e) =>
                    setSettings({ ...settings, phoneNumber: e.target.value })
                  }
                  placeholder="1800 001 345"
                />
              </div>

              <div>
                <Label htmlFor="companyEmail">Company Email</Label>
                <Input
                  id="companyEmail"
                  type="email"
                  value={settings.companyEmail}
                  onChange={(e) =>
                    setSettings({ ...settings, companyEmail: e.target.value })
                  }
                  placeholder="support@procrm.com"
                />
              </div>
            </CardContent>
          </Card>

          {/* Social Media Links */}
          <Card>
            <CardHeader>
              <CardTitle>Social Media Links</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="facebookUrl">Facebook URL</Label>
                <Input
                  id="facebookUrl"
                  value={settings.facebookUrl}
                  onChange={(e) =>
                    setSettings({ ...settings, facebookUrl: e.target.value })
                  }
                  placeholder="https://facebook.com/yourpage"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Leave empty to hide Facebook link
                </p>
              </div>

              <div>
                <Label htmlFor="linkedinUrl">LinkedIn URL</Label>
                <Input
                  id="linkedinUrl"
                  value={settings.linkedinUrl}
                  onChange={(e) =>
                    setSettings({ ...settings, linkedinUrl: e.target.value })
                  }
                  placeholder="https://linkedin.com/company/yourcompany"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Leave empty to hide LinkedIn link
                </p>
              </div>

              <div>
                <Label htmlFor="instagramUrl">Instagram URL</Label>
                <Input
                  id="instagramUrl"
                  value={settings.instagramUrl}
                  onChange={(e) =>
                    setSettings({ ...settings, instagramUrl: e.target.value })
                  }
                  placeholder="https://instagram.com/yourprofile"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Leave empty to hide Instagram link
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Acknowledgement Text */}
          <Card>
            <CardHeader>
              <CardTitle>Acknowledgement of Country</CardTitle>
            </CardHeader>
            <CardContent>
              <Label htmlFor="acknowledgementText">Acknowledgement Text</Label>
              <Textarea
                id="acknowledgementText"
                value={settings.acknowledgementText}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    acknowledgementText: e.target.value,
                  })
                }
                rows={6}
                placeholder="Enter your acknowledgement text..."
              />
              <p className="text-sm text-gray-500 mt-2">
                This text will appear at the bottom of the footer
              </p>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button
              onClick={handleSave}
              disabled={saving}
              size="lg"
              className="gap-2"
            >
              <Save className="h-4 w-4" />
              {saving ? "Saving..." : "Save Footer Settings"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
