
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";

export default function PrivacyPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 mb-8">
            Privacy Policy
          </h1>

          <div className="prose prose-lg max-w-none space-y-6 text-gray-700">
            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                1. Introduction
              </h2>
              <p>
                This Privacy Policy outlines how we collect, use, and protect
                your personal information. We are committed to ensuring that
                your privacy is protected.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                2. Information We Collect
              </h2>
              <p>We may collect the following information:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Name and contact information</li>
                <li>
                  Email address and phone number for communication purposes
                </li>
                <li>
                  Information relevant to NDIS services and support needs
                </li>
                <li>Other information relevant to customer surveys and offers</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                3. How We Use Your Information
              </h2>
              <p>
                We require this information to understand your needs and provide
                you with better services. Specifically:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>To provide NDIS registration and support services</li>
                <li>
                  Internal record keeping and improving our products and services
                </li>
                <li>
                  Sending promotional emails about new services or special offers
                </li>
                <li>
                  Contacting you for market research purposes via email, phone, or mail
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                4. Security
              </h2>
              <p>
                We are committed to ensuring that your information is secure. We
                have implemented suitable physical, electronic, and managerial
                procedures to safeguard and secure the information we collect
                online.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                5. Cookies
              </h2>
              <p>
                A cookie is a small file which asks permission to be placed on
                your computer's hard drive. Cookies allow web applications to
                respond to you as an individual and help us analyze web traffic.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                6. Links to Other Websites
              </h2>
              <p>
                Our website may contain links to other websites of interest.
                However, once you have used these links to leave our site, we do
                not have any control over that other website.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                7. Controlling Your Personal Information
              </h2>
              <p>
                You may choose to restrict the collection or use of your
                personal information. If you have previously agreed to us using
                your personal information for direct marketing purposes, you may
                change your mind at any time by contacting us.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                8. Contact Us
              </h2>
              <p>
                If you have any questions about this Privacy Policy, please
                contact us using the information on our Contact page.
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
