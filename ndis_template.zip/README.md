
# NDIS Registration Consultant Website Template

A professional, production-ready website template for NDIS (National Disability Insurance Scheme) registration consultants. Built with Next.js 14, TypeScript, Prisma, and Tailwind CSS.

## 🌟 Features

### Frontend
- **Modern, Responsive Design**: Beautiful purple/blue gradient theme with full mobile responsiveness
- **Hero Carousel**: Animated background slider with trust badges
- **Lead Capture Forms**: Dual forms with 30+ NDIS service categories
- **Pricing Cards**: Four customizable pricing packages with strikethrough pricing
- **Testimonials Carousel**: Auto-rotating client testimonials with photos
- **Why Choose Us Section**: Six benefit cards with icons
- **4-Step Process**: Visual timeline of the registration journey
- **FAQ Accordion**: Expandable frequently asked questions
- **Statistics Bar**: Animated counters that count up on scroll
- **Smooth Animations**: Framer Motion animations throughout

### Admin Panel
- **Dashboard**: Overview stats and recent leads
- **Leads Management**: View, filter, search, and export leads to CSV
- **Testimonials Manager**: Add, edit, delete, and reorder testimonials
- **Pricing Editor**: Update package prices and features
- **FAQs Manager**: Add, edit, delete, and reorder FAQs
- **Content Editor**: Update headlines, descriptions, and statistics
- **Settings Panel**: Configure site settings, colors, Stripe, calendar booking, social media

### Backend
- **RESTful API**: Complete API with authentication and CRUD operations
- **Database**: PostgreSQL with Prisma ORM (easily adaptable to MySQL)
- **Authentication**: NextAuth.js with email/password
- **File Uploads**: AWS S3 integration for logos and images
- **Form Validation**: Client and server-side validation
- **Security**: Password hashing, CSRF protection, SQL injection prevention

## 📋 Prerequisites

- Node.js 18+ and Yarn
- PostgreSQL database (or MySQL - see migration guide below)
- AWS S3 account (for file uploads)
- Stripe account (optional - for payments)
- Calendly or Google Calendar (optional - for bookings)

## 🚀 Quick Start

### 1. Installation

```bash
# Navigate to the project directory
cd ndis_template/nextjs_space

# Install dependencies (already done if using the template)
yarn install
```

### 2. Environment Configuration

Copy the `.env.example` file to `.env`:

```bash
cp .env.example .env
```

Update the `.env` file with your configuration:

```env
# Database (PostgreSQL - provided by default)
DATABASE_URL="postgresql://user:password@host:5432/dbname"

# NextAuth
NEXTAUTH_SECRET="your-secret-key-here"
NEXTAUTH_URL="http://localhost:3000"

# AWS S3 (for file uploads)
AWS_BUCKET_NAME="your-bucket-name"
AWS_FOLDER_PREFIX="uploads/"
AWS_ACCESS_KEY_ID="your-access-key"
AWS_SECRET_ACCESS_KEY="your-secret-key"
AWS_REGION="ap-southeast-2"

# Stripe (optional)
STRIPE_PUBLISHABLE_KEY="pk_test_..."
STRIPE_SECRET_KEY="sk_test_..."

# Email (optional - for notifications)
EMAIL_HOST="smtp.example.com"
EMAIL_PORT="587"
EMAIL_USER="your-email@example.com"
EMAIL_PASSWORD="your-password"
```

### 3. Database Setup

```bash
# Generate Prisma client
yarn prisma generate

# Push schema to database
yarn prisma db push

# Seed database with initial data
yarn prisma db seed
```

### 4. Run Development Server

```bash
yarn dev
```

Visit `http://localhost:3000` to see your website!

### 5. Admin Access

**Login Credentials:**
- Email: `admin@ndis.com`
- Password: `admin123`

Access the admin panel at: `http://localhost:3000/admin/login`

**⚠️ IMPORTANT:** Change the admin password immediately in production!

## 🗄️ MySQL Migration Guide

While this template uses PostgreSQL by default, you can easily migrate to MySQL:

### Step 1: Update Prisma Schema

Edit `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "mysql"  // Change from "postgresql"
  url      = env("DATABASE_URL")
}
```

### Step 2: Update Database URL

Update your `.env` file:

```env
DATABASE_URL="mysql://user:password@host:3306/dbname"
```

### Step 3: Adjust Field Types

MySQL has some differences. Update these in `schema.prisma`:

- `@db.Text` remains the same
- `cuid()` works the same way
- JSON fields are supported in MySQL 5.7+

### Step 4: Push Changes

```bash
yarn prisma generate
yarn prisma db push
yarn prisma db seed
```

### Recommended MySQL Hosting

- **PlanetScale**: Free tier, serverless MySQL
- **AWS RDS**: Production-grade with automated backups
- **Railway**: Easy deployment with MySQL
- **DigitalOcean Managed Databases**: Simple and reliable

## 🎨 Customization Guide

### Branding

1. **Logo**: Replace `/public/favicon.svg` with your logo
2. **Colors**: Use the admin panel Settings > Brand Colors
3. **Company Name**: Update in admin Settings panel
4. **OG Image**: Replace `/public/og-image.png`

### Content

All content is manageable via the admin panel:

- **Hero Section**: Admin > Content
- **Statistics**: Admin > Content
- **Pricing**: Admin > Pricing
- **Testimonials**: Admin > Testimonials
- **FAQs**: Admin > FAQs
- **Settings**: Admin > Settings

### Styling

The theme uses Tailwind CSS with custom colors:

```
Primary: Purple (#6B46C1)
Secondary: Blue (#3B82F6)
```

To change globally, edit `tailwind.config.ts`:

```typescript
theme: {
  extend: {
    colors: {
      primary: "#YOUR_COLOR",
      secondary: "#YOUR_COLOR",
    },
  },
}
```

## 📁 Project Structure

```
nextjs_space/
├── app/
│   ├── api/               # API routes
│   │   ├── auth/         # Authentication
│   │   ├── leads/        # Lead management
│   │   ├── testimonials/ # Testimonials CRUD
│   │   ├── pricing/      # Pricing management
│   │   ├── faqs/         # FAQs management
│   │   ├── content/      # Content management
│   │   ├── settings/     # Site settings
│   │   └── upload/       # File upload
│   ├── admin/            # Admin panel pages
│   │   ├── dashboard/
│   │   ├── leads/
│   │   ├── testimonials/
│   │   ├── pricing/
│   │   ├── faqs/
│   │   ├── content/
│   │   └── settings/
│   ├── about/            # About page
│   ├── contact/          # Contact page
│   ├── layout.tsx        # Root layout
│   └── page.tsx          # Homepage
├── components/           # React components
│   ├── ui/              # shadcn/ui components
│   ├── header.tsx
│   ├── footer.tsx
│   ├── hero-carousel.tsx
│   ├── statistics-bar.tsx
│   ├── lead-form.tsx
│   ├── pricing-cards.tsx
│   ├── testimonials-carousel.tsx
│   ├── why-choose-us.tsx
│   ├── process-steps.tsx
│   └── faq-accordion.tsx
├── lib/                  # Utilities
│   ├── db.ts            # Prisma client
│   ├── auth.ts          # Auth helpers
│   ├── auth-options.ts  # NextAuth config
│   ├── constants.ts     # App constants
│   └── utils.ts         # Utility functions
├── prisma/
│   └── schema.prisma    # Database schema
├── scripts/
│   └── seed.ts          # Database seeding
└── public/              # Static files
    ├── favicon.svg
    ├── og-image.png
    └── images/
```

## 🔐 Security

### Production Checklist

- [ ] Change all default passwords
- [ ] Update `NEXTAUTH_SECRET` with a secure random string
- [ ] Use environment variables for all secrets
- [ ] Enable HTTPS (handled by deployment platforms)
- [ ] Set up proper CORS policies
- [ ] Configure rate limiting
- [ ] Regular database backups
- [ ] Keep dependencies updated

### Generate Secure Secret

```bash
openssl rand -base64 32
```

## 🚢 Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Import project to Vercel
3. Add environment variables
4. Deploy!

Vercel automatically handles:
- SSL certificates
- CDN
- Automatic deployments
- Preview environments

### Other Platforms

- **Netlify**: Similar to Vercel
- **Railway**: Database + app hosting
- **Render**: Free tier available
- **AWS/DigitalOcean**: Full control

### Database Hosting

For production databases:

**PostgreSQL:**
- Vercel Postgres
- Railway
- Supabase
- AWS RDS

**MySQL:**
- PlanetScale
- Railway
- AWS RDS
- DigitalOcean

## 📧 Email Notifications

To enable email notifications when leads submit forms:

1. Update email settings in `.env`
2. Implement the email service in `app/api/leads/route.ts`
3. Use Nodemailer or a service like SendGrid/Mailgun

Example Nodemailer setup:

```typescript
import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: parseInt(process.env.EMAIL_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD,
  },
});

// Send email
await transporter.sendMail({
  from: process.env.EMAIL_USER,
  to: 'admin@example.com',
  subject: 'New NDIS Lead',
  html: `<p>New lead from ${firstName} ${lastName}</p>`,
});
```

## 💳 Stripe Integration

### Setup

1. Get your Stripe API keys from the [Stripe Dashboard](https://dashboard.stripe.com/)
2. Add keys to admin Settings panel or `.env`
3. Create products in Stripe Dashboard
4. Update pricing package IDs in the database

### Implementing Checkout

```typescript
// Example checkout session creation
const session = await stripe.checkout.sessions.create({
  payment_method_types: ['card'],
  line_items: [{
    price: 'price_xxxxx', // Stripe price ID
    quantity: 1,
  }],
  mode: 'payment',
  success_url: `${YOUR_DOMAIN}/success`,
  cancel_url: `${YOUR_DOMAIN}/cancel`,
});
```

## 📅 Calendar Integration

### Calendly

1. Get your Calendly booking link
2. Add to admin Settings > Booking Link
3. Use in your "Register Now" buttons

### Google Calendar

1. Create a booking page in Google Calendar
2. Get the shareable link
3. Add to admin Settings

## 🐛 Troubleshooting

### Database Connection Issues

```bash
# Test database connection
yarn prisma studio
```

### Build Errors

```bash
# Clear Next.js cache
rm -rf .next

# Reinstall dependencies
rm -rf node_modules
yarn install

# Regenerate Prisma client
yarn prisma generate
```

### Image Upload Issues

- Check AWS credentials in `.env`
- Verify S3 bucket permissions
- Ensure bucket is in correct region

## 📚 API Documentation

### Authentication

**POST** `/api/auth/signin` - Sign in
**POST** `/api/signup` - Create new user

### Leads

**GET** `/api/leads` - Get all leads (admin only)
**POST** `/api/leads` - Create new lead
**PATCH** `/api/leads/:id` - Update lead status
**GET** `/api/leads/export` - Export leads to CSV

### Testimonials

**GET** `/api/testimonials` - Get all testimonials
**POST** `/api/testimonials` - Create testimonial (admin)
**PATCH** `/api/testimonials/:id` - Update testimonial (admin)
**DELETE** `/api/testimonials/:id` - Delete testimonial (admin)
**PATCH** `/api/testimonials/reorder` - Reorder testimonials (admin)

### Pricing

**GET** `/api/pricing` - Get all packages
**PATCH** `/api/pricing/:id` - Update package (admin)

### FAQs

**GET** `/api/faqs` - Get all FAQs
**POST** `/api/faqs` - Create FAQ (admin)
**PATCH** `/api/faqs/:id` - Update FAQ (admin)
**DELETE** `/api/faqs/:id` - Delete FAQ (admin)
**PATCH** `/api/faqs/reorder` - Reorder FAQs (admin)

### Content

**GET** `/api/content` - Get all content
**PATCH** `/api/content` - Update content (admin)

### Settings

**GET** `/api/settings` - Get site settings
**PATCH** `/api/settings` - Update settings (admin)

## 🤝 Support

For issues or questions:

1. Check the documentation above
2. Review the code comments
3. Check the FAQ section
4. Contact your developer

## 📄 License

This template is provided for commercial use. Modify and customize as needed for your business.

## 🎯 Next Steps

1. ✅ Complete the Quick Start guide
2. ✅ Change default admin password
3. ✅ Customize branding (logo, colors, content)
4. ✅ Update pricing packages
5. ✅ Add your testimonials
6. ✅ Configure Stripe (if using payments)
7. ✅ Set up calendar booking
8. ✅ Test all forms and features
9. ✅ Deploy to production
10. ✅ Set up domain and SSL

## 🚀 Ready to Launch!

Your NDIS registration consultant website is now ready to use. Customize it to match your brand and start collecting leads!

For production deployment, remember to:
- Use a production database
- Update all environment variables
- Enable HTTPS
- Set up monitoring and backups
- Configure email notifications
- Test thoroughly before going live

Good luck with your NDIS consulting business! 🎉
